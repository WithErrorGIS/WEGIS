'''03/10/2022, zy yin, H:/2022/Homework/WEGISsystem/week3
python 3.9.12, pyqt 5.15.4
window form for calculating slope and aspect from input raster
form: SlopeAsp.ui/Ui_SlopeAsp.py
main function: Main_SlopeAsp.py'''

'''input: raster
processing: gdal read raster, get information, calculate slope/aspect
output: ascii array'''


'''-------------import installed packages-------------'''
from dataclasses import dataclass
import sys
from osgeo import gdal,ogr,osr
import numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QTextBrowser, QVBoxLayout, QHBoxLayout, QMessageBox
from PyQt5.QtGui import QIcon
from matplotlib import pyplot as plt


'''-------------import custom modules------------'''
from WEGIS.develop.UI import Ui_D8
import D8Cal
import processings


'''-------window class-----------'''
class Windowd8_yzy(Ui_D8.Ui_D8_Win, QtWidgets.QMainWindow): #Windowd8_yzy: yzy class-- input raser, calculate flow direction
    def __init__(self):
        super(Windowd8_yzy, self).__init__()
        self.setupUi(self)

        #*********************global variables********************************
        inputfile=""
        outputfile=""

        ###=======click browsein button to select input file=====================
        #-----------------------------------------------------------------------
        self.browsein.clicked.connect(self.msgin) #def msgin(self):

        #=-----------------------------------------------------------------------

        ###=======click browseout button to select output file=======================
        #-----------------------------------------------------------------------
        self.browseout.clicked.connect(self.msgout) #def msgout(self):

        #=-----------------------------------------------------------------------

        ###=======click cancel to close form=======================
        #-----------------------------------------------------------------------
        self.cancel.clicked.connect(QCoreApplication.instance().quit)

        #=-----------------------------------------------------------------------

        ###=======click ok to complete calculation=======================
        #-----------------------------------------------------------------------
        self.ok.clicked.connect(self.calculateSlpAsp) #def calculateSlpAsp:        
        
        #=-----------------------------------------------------------------------




    '''functions'''


    '''click browsein:
    ----------show file path--------------------------------------'''

    def msgin(self):
        #===============open shapefile====================
        filePath, filetype = QtWidgets.QFileDialog.getOpenFileName(self, "Select File", "./","*.*")
        
        #==================print filename===============
        self.filenamein.setText(filePath)

        #=======================gdal readfile==========================
        try:
            rasterin=gdal.Open(filePath)
            global inputfile
            inputfile=filePath
       
        except:
            msg_box = QMessageBox(QMessageBox.Warning, 'Warning', 'Cannot open file!')
            msg_box.exec_()


    '''click browseout:
    ----------show file path--------------------------------------
    ----------set selected file as output file------------------------------------
    ----------output to file------------------------------'''

    def msgout(self):
        #===============open shapefile====================
        filePath, filetype = QtWidgets.QFileDialog.getOpenFileName(self, "Select File", "./","*.*")
        
        #==================print filename===============
        self.filenameout.setText(filePath)

        #===================set output filename as global============================
        global outputfile
        outputfile=filePath


    '''click ok:
    --------------------calculate slope/aspect------------------------------'''
    def calculateSlpAsp(self):
        
        #==============read raster file=================
        dataset=gdal.Open(inputfile)
        proj=dataset.GetProjection()
        geotrans=dataset.GetGeoTransform()
        width=geotrans[1]
        height=geotrans[5]
        row=dataset.RasterYSize
        column=dataset.RasterXSize
        band=dataset.RasterCount

        demgrid=dataset.ReadAsArray(0,0,column,row)

        typedata=demgrid.dtype

        
        direction=D8Cal.D8all(demgrid,row,column)
        processings.write_img(outputfile, proj, geotrans, direction, typedata)
        msg_box = QMessageBox(QMessageBox.Information, 'Calculation done', 'Calculation Successful!')
        msg_box.exec_()
      



'''-----------------------------------------------------------------------------------------------
============main==================main==========================main===========================
-----------------------------------------------------------------------------------------------'''
if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    mywindow = Windowd8_yzy()
    mywindow.show()
    sys.exit(app.exec_())