'''18/09/2022, zy yin, H:/2022/Homework/WEGISsystem/week1
python 3.9.12, pyqt 5.15.4
window form for input data: input shapefile data
form: InputShapeUI.ui/InputShapeUI.py
main function: InputShape.py'''

'''input: esri shapefile
processing: geopandas read shapefile, create geometry
output: geometry geodataframe
no projection involved'''


'''-------------import installed packages-------------'''
from dataclasses import dataclass
import sys
import numpy as np
import pandas as pd
import geopandas as gpd
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QTextBrowser, QVBoxLayout, QHBoxLayout, QMessageBox
from PyQt5.QtGui import QIcon
from matplotlib import pyplot as plt


'''-------------import custom modules------------'''
import Ui_shapefiledata


'''-------window class-----------'''
class Windowinshape_yzy(Ui_shapefiledata.Ui_InputCsv_Win, QtWidgets.QMainWindow): #windowinshape_yzy: yzy class--input shapefile data
    def __init__(self):
        super(Windowinshape_yzy, self).__init__()
        self.setupUi(self)

        #*********************global variables********************************
        datageometry=gpd.GeoDataFrame()


        ###=======click browse button to select input file=======================
        #-----------------------------------------------------------------------
        self.browse.clicked.connect(self.msg) #def msg(self):

        #=-----------------------------------------------------------------------


        ###=======click cancel to close form=======================
        #-----------------------------------------------------------------------
        self.cancel.clicked.connect(QCoreApplication.instance().quit)

        #=-----------------------------------------------------------------------


        ###=======click ok to import geometry=======================
        #-----------------------------------------------------------------------
        self.okk.clicked.connect(self.okfunction) #def okfunction:     
        
        #=-----------------------------------------------------------------------


    '''functions'''


    '''click browse:
    ----------show file path--------------------------------------
    ----------read file content------------------------------------
    ----------convert to geodataframe------------------------------
    ----------preview type and attributes------------------------------'''

    def msg(self):
        #===============open shapefile====================
        filePath, filetype = QtWidgets.QFileDialog.getOpenFileName(self, "Select File", "./","*.shp")
        
        #==================print filename===============
        self.browsefile.setText(filePath)

        #============read file content==============
        global datageometry
        datageometry=gpd.read_file(filePath)

        #==================data preview===================

        #geometry type
        gtype=str(datageometry.geom_type)
        self.geotype.setText(gtype)

        #attribute list
        atts=datageometry.columns.to_list()
        atts_print=str(atts)
        self.attributes.setText(atts_print)
    

    '''click ok'''
    def okfunction(self):
        msg_box = QMessageBox(QMessageBox.Information, 'Input done', 'Successfully imported geometry!')
        msg_box.exec_()



'''-----------------------------------------------------------------------------------------------
============main==================main==========================main===========================
-----------------------------------------------------------------------------------------------'''
if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    mywindow = Windowinshape_yzy()
    mywindow.show()
    sys.exit(app.exec_())

