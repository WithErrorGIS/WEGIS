import os
import time
import sys
from ui import Ui_Form
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *

FileName = os.path.basename(sys.argv[0])
FilePath = sys.argv[0].replace(FileName,"")
UiName = FileName.replace(".py",".ui")
UiPath = FilePath +UiName
Ui_pyName = FilePath+"ui.py"
FileFlag = os.path.isfile(Ui_pyName)

if FileFlag == 0:
	sys_cmd	 = os.popen("pyuic5 "+UiPath+" -o "+Ui_pyName)
	time.sleep(1)

class m_window(QWidget, Ui_Form, QPainter):
    def __init__(self):
        super(m_window, self).__init__()
        self.setupUi(self)
        self.pushButton_1.clicked.connect(self.DrawPoint)
        self.pushButton_2.clicked.connect(self.DrawLine)
        self.pushButton_3.clicked.connect(self.DrawPolygon)
        self.Draw = ""
        self.Line_list = [0, 0, 0, 0]
        self.Point_list = []
        self.Polygon_list = []

    def DrawPoint(self):
        self.update()
        self.Draw = "Point"

    def DrawLine(self):
        self.update()
        self.Draw = "Line"

    def DrawPolygon(self):
        self.update()
        self.Draw = "Polygon"

    def paintEvent(self, QPaintEvent):
        painter = QPainter(self)
        painter.setPen(QColor(166, 66, 250))
        pen = QPen()
        pen.setWidth(10) # Size
        painter.setPen(pen)
        painter.begin(self)
        if self.Draw == "Point":
            len_point_list = len(self.Point_list) / 2
            for i in range(int(len_point_list)):
                painter.drawPoint(self.Point_list[i * 2], self.Point_list[i * 2 + 1])
            print("DrawPoint")
        elif self.Draw == "Line":
            painter.drawLine(self.Line_list[0], self.Line_list[1], self.Line_list[2], self.Line_list[3])
            print("DrawLine")
        elif self.Draw == "Polygon":
            polygon = QPolygon()
            if len(self.Polygon_list) >= 6:
                polygon.setPoints(self.Polygon_list)
                print(len(self.Polygon_list))
                painter.drawPolygon(polygon)
            print("DrawPolygon")
        painter.end()

    def mousePressEvent(self, e):
        if self.Draw == "Line":
            self.Line_list[0] = e.x()
            self.Line_list[1] = e.y()
            print("start", self.Line_list[0], self.Line_list[1])
        elif self.Draw == "Point":
            self.Point_list.append(e.x())
            self.Point_list.append(e.y())
            self.update()
        elif self.Draw == "Polygon":
            self.Polygon_list.append(e.x())
            self.Polygon_list.append(e.y())
            print(self.Polygon_list)
            self.update()

        if e.button() == Qt.RightButton:
            self.Point_list.clear()
            self.Polygon_list.clear()
            self.update()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton:
            print("左键")
        elif e.button() == Qt.RightButton:
            print("右键")
        elif e.button() == Qt.MidButton:
            print("点击滚轮")

    def mouseMoveEvent(self, e):
        if self.Draw == "Line":
            self.Line_list[2] = e.x()
            self.Line_list[3] = e.y()
            print("end", self.Line_list[2], self.Line_list[3])
            self.update()


app = QApplication(sys.argv)
window = m_window()
window.show()
sys.exit(app.exec_())