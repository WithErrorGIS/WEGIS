from PyQt5 import QtCore, QtGui, QtWidgets

# Ui类，绘制三个button，分别为点线面
class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(400, 300)
        self.pushButton_1 = QtWidgets.QPushButton(Form)
        self.pushButton_1.setStyleSheet(
            '''QPushButton{background:#F7D674;border-radius:5px;}QPushButton:hover{background:yellow;}''')
        self.pushButton_1.setGeometry(QtCore.QRect(10, 10, 75, 23))
        self.pushButton_1.setObjectName("pushButton_1")
        self.pushButton_2 = QtWidgets.QPushButton(Form)
        self.pushButton_2.setStyleSheet(
            '''QPushButton{background:#F7D674;border-radius:5px;}QPushButton:hover{background:yellow;}''')
        self.pushButton_2.setGeometry(QtCore.QRect(10, 40, 75, 23))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_3 = QtWidgets.QPushButton(Form)
        self.pushButton_3.setStyleSheet(
            '''QPushButton{background:#F7D674;border-radius:5px;}QPushButton:hover{background:yellow;}''')
        self.pushButton_3.setGeometry(QtCore.QRect(10, 70, 75, 23))
        self.pushButton_3.setObjectName("pushButton_3")
        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "WEGISForm"))
        self.pushButton_1.setText(_translate("Form", "添加点"))
        self.pushButton_2.setText(_translate("Form", "添加线"))
        self.pushButton_3.setText(_translate("Form", "添加面"))


