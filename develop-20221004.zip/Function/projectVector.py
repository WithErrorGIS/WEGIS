'''25/09/2022, zy yin, H:/2022/Homework/WEGISsystem/week2
python 3.9.12, pyqt 5.15.4
window form for vector projection: projectVector
form: projectionVector.ui/Ui_projectionVector.py
main function: projectVector.py'''

'''input: shape file
processing: Lambert and Mercator Projections from basic mathematical principles
output: shape file'''


'''-------------import installed packages-------------'''
from dataclasses import dataclass
import sys
import numpy as np
import pandas as pd
import geopandas as gpd
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QTextBrowser, QVBoxLayout, QHBoxLayout, QMessageBox
from PyQt5.QtGui import QIcon
import math
import os
from osgeo import gdal

'''-------------import custom modules------------'''
import Ui_projectionVector
import lambertProjection
import MercatorProjection

'''-------window class-----------'''
class Windowprjv_yzy(Ui_projectionVector.Ui_Projection_Win, QtWidgets.QMainWindow): #windowprjv_yzy: yzy class--vector projection
    def __init__(self):
        super(Windowprjv_yzy, self).__init__()
        self.setupUi(self)
        
        #*********************global variables********************************
        datagdf=gpd.GeoDataFrame()
        projectedlist=[]
        prjtype=""

        ###=======click browse button to select input file=======================
        #-----------------------------------------------------------------------
        self.browsein.clicked.connect(self.msg) #def msg(self):

        #=-----------------------------------------------------------------------


        ###========click cancel to close window==================================
        #-----------------------------------------------------------------------
        self.cancel.clicked.connect(QCoreApplication.instance().quit)

        #-----------------------------------------------------------------------


        ###========select xy in combo box=======================================
        #-----------------------------------------------------------------------
       
        #combox select a column index from dataframe field list
        
        self.comboBox.currentIndexChanged.connect(self.setproject) #def setproject(self):

        #-----------------------------------------------------------------------


        ###========click ok to create geometry====================================
        #-----------------------------------------------------------------------

        self.okk.clicked.connect(self.okfunction) #def okfunction:

        #-----------------------------------------------------------------------


    '''functions'''

    '''click browse:
    ----------show file path------------------------------------------
    ----------return file path for projection-------------------------'''

    def msg(self):

        #===============open csv file====================
        filePath, filetype = QtWidgets.QFileDialog.getOpenFileName(self, "Select File", "./","*.shp") #shapefile input for projection
        
        #==================print filename===============
        self.infile.setText(filePath)

        #==================read file content===============
        gdf=gpd.read_file(filePath)

        #==================return filename for projection================
        global datagdf
        datagdf=gdf

    
    '''click combo box:
    ------------------select projection type-----------------------------------'''
    def setproject(self):
        prjtype1=self.comboBox.currentText()
        global prjtype
        prjtype=prjtype1


    '''click ok
    ------------------project-----------------------------------'''
    def okfunction(self):
        global projectedlist

        if (prjtype=="Lambert Projection"):
            projectedvec=lambertProjection.testing.projtionLam(datagdf)
            projectedlist=projectedvec
        
        if (prjtype=="Mercator Projection"):
            projectedvec=MercatorProjection.testing.projtionMec(datagdf)
            projectedlist=projectedvec

        msg_box = QMessageBox(QMessageBox.Information, 'Input done', 'Successfully imported geometry!')
        msg_box.exec_()



'''-----------------------------------------------------------------------------------------------
============main==================main==========================main===========================
-----------------------------------------------------------------------------------------------'''
if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    mywindow = Windowprjv_yzy()
    mywindow.show()
    sys.exit(app.exec_())