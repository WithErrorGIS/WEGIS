'''17/09/2022, zy yin, H:/2022/Homework/WEGISsystem/week1
python 3.9.12, pyqt 5.15.4
window form for input data: input xy data
form: InputCsvUI.ui/InputCsvUI.py
main function: InputCsv.py'''

'''input: csv file
processing: pandas readfile, lat/lon selection and geopandas conversion
output: geometry geodataframe
no projection involved'''

'''-------------import custom modules------------'''
import sys

'''-------------import installed packages-------------'''
import pandas as pd
import geopandas as gpd
from PyQt5 import QtGui, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtWidgets import QMessageBox
from WEGIS.develop.UI import InputCsvUI

'''-------window class-----------'''
class Windowinxy_yzy(InputCsvUI.Ui_InputCsv_Win, QtWidgets.QMainWindow): #windowinxy_yzy: yzy class--input xy data
    def __init__(self):
        super(Windowinxy_yzy, self).__init__()
        self.setupUi(self)
        
        #*********************global variables********************************
        datadf=pd.DataFrame()
        xfielder=0
        yfielder=0
        datageometry=gpd.GeoDataFrame()

        ###=======click browse button to select input file=======================
        #-----------------------------------------------------------------------
        self.browse.clicked.connect(self.msg) #def msg(self):

        #=-----------------------------------------------------------------------


        ###========click cancel to close window==================================
        #-----------------------------------------------------------------------
        self.cancel.clicked.connect(QCoreApplication.instance().quit)

        #-----------------------------------------------------------------------


        ###========select xy in combo box=======================================
        #-----------------------------------------------------------------------
       
        #combox select a column index from dataframe field list
        
        self.xField.currentIndexChanged.connect(self.setx) #def setx(self):
        self.yField.currentIndexChanged.connect(self.sety) #def sety(self):

        #-----------------------------------------------------------------------


        ###========click ok to create geometry====================================
        #-----------------------------------------------------------------------

        self.ok.clicked.connect(self.toGeometry)

        #-----------------------------------------------------------------------
    



    '''functions'''

    '''click browse:
    ----------show file path--------------------------------------
    ----------read file content------------------------------------
    ----------show file content in table view------------------
    ----------add field names to combo-------------------------'''

    def msg(self):

        #===============open csv file====================
        filePath, filetype = QtWidgets.QFileDialog.getOpenFileName(self, "Select File", "./","*.csv") #only csv file allowed in current version
        
        #==================print filename===============
        self.filename.setText(filePath)

        #============read file content==============
        df=pd.read_csv(filePath) #df: dataframe

        #==================show file content================
        #################
        #shape of table

        df_rows=df.shape[0]
        df_cols=df.shape[1]

        dfarray=df.values

        self.model=QtGui.QStandardItemModel(df_rows,df_cols)

        #write to table: loop 
        for row in range(df_rows):
            for col in range(df_cols):
                item=QtGui.QStandardItem(str(dfarray[row][col]))
                self.model.setItem(row, col, item)
        
        self.tableView.setModel(self.model)

        ###################

        #===================save dataframe for use===========
        global datadf
        datadf=df

        #=======================field list added to combo========================
        indexcol=list(datadf.columns.values)
        self.xField.addItems(indexcol)
        self.yField.addItems(indexcol)


    '''click combo box:
    ------------------select lat----------------------------------
    ------------------select lon-----------------------------------'''
    def setx(self):
        global xfielder
        xfielder=self.xField.currentText()
        
    def sety(self):
        global yfielder
        yfielder=self.yField.currentText()


    '''click ok:
    -------------------create geodataframe geometry-------------
    -------------------close window-----------------------------'''

    def toGeometry(self):
        
        try:
            gdf_fromxy=gpd.GeoDataFrame(datadf,geometry=gpd.points_from_xy(datadf[xfielder],datadf[yfielder]))
            global datageometry
            datageometry=gdf_fromxy

            msg_box = QMessageBox(QMessageBox.Information, 'Input done', 'Successfully created geometry!')
            msg_box.exec_()

        except:
            msg_box = QMessageBox(QMessageBox.Warning, 'Warning', 'Input field error!')
            msg_box.exec_()


'''-----------------------------------------------------------------------------------------------
============main==================main==========================main===========================
-----------------------------------------------------------------------------------------------'''
if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    mywindow = Windowinxy_yzy()
    mywindow.show()
    sys.exit(app.exec_())


