'''Class AspCal:
calculate aspect from input raster data'''

import numpy as np
import math
from osgeo import gdal,ogr,osr


def CalAsp(npgrid,sizex,sizey):
    nx, ny = npgrid.shape
    a_dx = np.zeros((nx, ny))
    a_dy = np.zeros((nx, ny))
    s_dx = np.zeros((nx,ny))
    s_dy = np.zeros((nx,ny))

    for i in range(1,nx-1):
        for j in range(1,ny-1):
            s_dx[i,j] = ((npgrid[i-1,j+1]+2*npgrid[i,j+1]+npgrid[i+1,j+1])-(npgrid[i-1,j-1]+2*npgrid[i,j-1]+npgrid[i+1,j-1])) / (8 * sizex)
            s_dy[i, j] = ((npgrid[i+1, j-1] + 2 * npgrid[i+1, j] + npgrid[i+1,j+1])-(npgrid[i-1,j-1]+2 * npgrid[i-1,j] + npgrid[i-1,j+1])) / (8 * sizey)
 
    a_dx=s_dx*sizex
    a_dy=s_dy*sizey

    s_dx = s_dx[1:-1,1:-1]
    s_dy = s_dy[1:-1,1:-1]
    a_dx = a_dx[1:-1, 1:-1]
    a_dy = a_dy[1:-1, 1:-1]

    #===aspect===
    a=np.zeros((a_dy.shape[0],a_dy.shape[1]))
    for i in range(0,a_dx.shape[0]):
        for j in range(0,a_dx.shape[1]):
            a[i,j] = math.atan2(a_dy[i,j], -a_dx[i,j]) * 180 / math.pi
    
    aspect=a

    #=================convert to 0-360 degrees================================
    x, y = a.shape[0],a.shape[1]
    for m in range(0,x):
        for n in range(0,y):
            if a[m,n] < 0:
                aspect[m,n] = 90-a[m,n]
            elif a[m,n] > 90:
                aspect[m,n] = 360.0 - a[m,n] + 90.0
            else:
                aspect[m,n] =  90.0 - a[m,n]


    return aspect
