import math
import os
from osgeo import gdal
import geopandas as gpd
import json
from shapely.geometry import Point
from shapely import geometry


class parameters:
    #constants of Krassovsky ellipsoid

    class const_54:
        a=6378245.0
        sqe=0.006693421622966
        e=math.sqrt(sqe)
    #constants of lambert(not change for testing)
    class const_lambert:
        nf=0.0
        ef=609600.0
    #constants of lambert when using common parameters
    class const_lamC:
        lon_o=1.8325957145940461  #105E
        lat_o=0.5235987755982988 #30N
        lat1=0.4363323129985824  #25N
        lat2=0.8203047484373349  #47N
        
    #calculating parameters
    class params:
        @staticmethod
        def theta(n,lamda,lamdaf):
            return n*(lamda-lamdaf)

        @staticmethod
        def n(m1,m2,t1,t2): 
            return (math.log(m1)-math.log(m2))/(math.log(t1)-math.log(t2))
        @staticmethod

        def m(phi): #phi1,phi2: standard parallels
            temp1=parameters.const_54.sqe*math.sin(phi)*math.sin(phi)
            temp2=math.sqrt(1-temp1)
            return math.cos(phi)/temp2

        @staticmethod
        def t(phi): #phi1,phi2: standard parallels; phif: latitude of origin; phi: input phi
            temp1=(1-parameters.const_54.e*math.sin(phi))/(1+parameters.const_54.e*math.sin(phi))
            temp2=math.pow(temp1,(parameters.const_54.e/2))
            temp3=math.tan(math.pi/4-phi/2)
            return temp3/temp2

        @staticmethod
        def F(m1,n,t1):
            return m1/(n*math.pow(t1,n))
            #return m1/(n*t1)**n

        @staticmethod
        def r(F,t,n):
            return parameters.const_54.a*F*t**n

    

class project:
    #project function
    @staticmethod
    def E(r,theta):
        return (parameters.const_lambert.ef+r*math.sin(theta))
    @staticmethod
    def N(rf,r,theta):
        return (parameters.const_lambert.nf+rf-r*math.cos(theta))

class testing():
    #calculate parameters
    @staticmethod
    def calculate(phi1,phi2,phif,lamdaf,phi,lamda):
        #parameters
        m1=parameters.params.m(phi1)
        m2=parameters.params.m(phi2)
        t1=parameters.params.t(phi1)
        t2=parameters.params.t(phi2)
        tf=parameters.params.t(phif)
        t=parameters.params.t(phi)
        n=parameters.params.n(m1,m2,t1,t2)
        F=parameters.params.F(m1,n,t1)
        r=parameters.params.r(F,t,n)
        rf=parameters.params.r(F,tf,n)
        theta=parameters.params.theta(n,lamda,lamdaf)

        #project
        E=project.E(r,theta)
        N=project.N(rf,r,theta)
        return [E,N]



    #lambert when using common parameters
    @staticmethod
    def lamC(phi,lamda):
        
        phif=parameters.const_lamC.lat_o
        lamdaf=parameters.const_lamC.lon_o
        phi1=parameters.const_lamC.lat1
        phi2=parameters.const_lamC.lat2
        E,N=testing.calculate(phi1,phi2,phif,lamdaf,phi,lamda)
        #Clist.append([E,N])
        return [E,N]

    #-------------------projection function
    #======================================================
    def projtionLam(gdf):

        projected_all=[]

        #get geometry vertices coordiantes
        for index, row in gdf.iterrows():
            multi = row.geometry.type.startswith("Multi") #check if multi

            if multi:
                projected_part=[]
                # iterate over all parts of multigeometry
                for part in row.geometry:
                    corrdver=part.exterior.coords
                    prjedpoints=[]
                    for pt in list(corrdver):
                        phi=(pt[1]/360)*2*math.pi
                        lamda=(pt[0]/360)*2*math.pi
                        Eprj,Nprj=testing.lamC(phi,lamda) #projecting
                        prjedpoints.append(geometry.Point(Eprj,Nprj))
                    projected_part.append(geometry.Polygon(prjedpoints))
            

            else:
                prjedpoints=[]
                for pt in list(row['geometry'].exterior.coords):
                    phi=(pt[1]/360)*2*math.pi
                    lamda=(pt[0]/360)*2*math.pi
                    Eprj,Nprj=testing.lamC(phi,lamda) #projecting
                    prjedpoints.append(geometry.Point(Eprj,Nprj))
                projected_all.append(geometry.Polygon(prjedpoints))
        

        return projected_all



