# -*- coding: utf-8 -*-
try:
    from osgeo import gdal
    from osgeo import ogr
    from osgeo import osr
except ImportError:
    import gdal
    import ogr
    import osr
 
  
class ShapeReadWrite:
 
     # 读shp文件,几何数据
    def readShp(self,shpfilePath):
        # 支持中文路径
        gdal.SetConfigOption("GDAL_FILENAME_IS_UTF8", "YES")
        # 支持中文编码
        gdal.SetConfigOption("SHAPE_ENCODING", "UTF-8")
        # 注册所有的驱动
        ogr.RegisterAll()
        # 打开数据
        ds = ogr.Open(shpfilePath, 0)
        if ds == None:
            return "打开文件失败！"
        # 获取数据源中的图层个数，shp数据图层只有一个，gdb、dxf会有多个
        iLayerCount = ds.GetLayerCount()
        print("图层个数 = ", iLayerCount)
        # 获取第一个图层
        oLayer = ds.GetLayerByIndex(0)
        if oLayer == None:
            return "获取图层失败！"
        # 对图层进行初始化
        oLayer.ResetReading()
                
        # 输出图层中的要素个数
        num = oLayer.GetFeatureCount(0)
        print("要素个数 = ", num)
        result_list = []
        # 获取要素
        for i in range(0, num):
            ofeature = oLayer.GetFeature(i)
            id = ofeature.GetFieldAsString("id")
            name = ofeature.GetFieldAsString('name')
            geom = str(ofeature.GetGeometryRef())
            result_list.append([id,name,geom])
        ds.Destroy()
        del ds
        return result_list
    
     
    
    #------------------------------
    #read shape file  几何数据，属性数据
    #------------------------------
    def read_shp(self,file):
        # 支持中文路径
        gdal.SetConfigOption("GDAL_FILENAME_IS_UTF8", "YES")
        # 支持中文编码
        gdal.SetConfigOption("SHAPE_ENCODING", "UTF-8")
        # 注册所有的驱动
        ogr.RegisterAll()
        #open
        ds = ogr.Open(file,False) #False - read only, True - read/write
        layer = ds.GetLayer(0)
        #fields
        lydefn = layer.GetLayerDefn()
        spatialref = layer.GetSpatialRef()
        geomtype = lydefn.GetGeomType() 
        fieldlist = []
        for i in range(lydefn.GetFieldCount()):
            fddefn = lydefn.GetFieldDefn(i)
            fddict = {'name':fddefn.GetName(),'type':fddefn.GetType(),
                      'width':fddefn.GetWidth(),'decimal':fddefn.GetPrecision()}
            fieldlist += [fddict]
        #records
        geomlist = []
        reclist = []
        feature = layer.GetNextFeature()
        while feature is not None:
            geom = feature.GetGeometryRef()
            geomlist += [geom.ExportToWkt()]
            rec = {}
            for fd in fieldlist:
                rec[fd['name']] = feature.GetField(fd['name'])
            reclist += [rec]
            feature = layer.GetNextFeature()
        #close
        ds.Destroy()
        return (spatialref,geomtype,geomlist,fieldlist,reclist)

  
    #------------------------------
    #write shape file
    #------------------------------
    def write_shp(self,file,data):
        # 支持中文路径
        gdal.SetConfigOption("GDAL_FILENAME_IS_UTF8", "YES")
        # 支持中文编码
        gdal.SetConfigOption("SHAPE_ENCODING", "UTF-8")
        # 注册所有的驱动
        ogr.RegisterAll()

        spatialref,geomtype,geomlist,fieldlist,reclist = data
        #create
        driver = ogr.GetDriverByName("ESRI Shapefile")
        if os.access(file, os.F_OK ):
            driver.DeleteDataSource(file)
        ds = driver.CreateDataSource(file)
        if ds == None:
            return "创建文件失败"
        layer = ds.CreateLayer(file[:-4],srs=spatialref,geom_type=geomtype)
        #fields
        for fd in fieldlist:
            field = ogr.FieldDefn(fd['name'],fd['type'])
            if fd.has_key('width'):
                field.SetWidth(fd['width'])
            if fd.has_key('decimal'):
                field.SetPrecision(fd['decimal'])
            layer.CreateField(field)
        #records
        for i in range(len(reclist)):
            geom = ogr.CreateGeometryFromWkt(geomlist[i])
            feat = ogr.Feature(layer.GetLayerDefn())
            feat.SetGeometry(geom)
            for fd in fieldlist:
                # print(fd['name'],reclist[i][fd['name']])
                feat.SetField(fd['name'],reclist[i][fd['name']])
            layer.CreateFeature(feat)
        #close
        ds.Destroy()
        return "数据集创建完成！"


if __name__ == '__main__': 
    test = ShapeReadWrite()
    #writeResult = test.write_shp("aaa.shp",data)
    #print(writeResult)
    readResult = read_Shp("aaa.shp")
    print(readResult)