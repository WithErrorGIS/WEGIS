'''03/10/2022, zy yin, H:/2022/Homework/WEGISsystem/week3
python 3.9.12, pyqt 5.15.4
window form for calculating slope and aspect from input raster
form: SlopeAsp.ui/Ui_SlopeAsp.py
main function: Main_SlopeAsp.py'''

'''input: raster
processing: gdal read raster, get information, calculate slope/aspect
output: ascii array'''


'''-------------import installed packages-------------'''
from dataclasses import dataclass
import sys
from osgeo import gdal,ogr,osr
import numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QTextBrowser, QVBoxLayout, QHBoxLayout, QMessageBox
from PyQt5.QtGui import QIcon
from matplotlib import pyplot as plt

'''-------------import custom modules------------'''
from WEGIS.develop.UI import Ui_interp
from WEGIS.develop.Function import idw
from WEGIS.develop.Function import gdalrw
from WEGIS.develop.Function import vario
'''-------window class-----------'''
class Windowinterp_yzy(Ui_interp.Ui_MainWindow, QtWidgets.QDialog): #Windowd8_yzy: yzy class-- input raser, calculate flow direction
    def __init__(self):
        super(Windowinterp_yzy, self).__init__()
        self.setupUi(self)

        #*********************global variables********************************
        inputfile=""
        outputfile=""

        #=-----------------------------------------------------------------------

        ###=======click cancel to close form=======================
        #-----------------------------------------------------------------------
        self.cancel.clicked.connect(QCoreApplication.instance().quit)

        #=-----------------------------------------------------------------------

        ###=======click ok to complete calculation=======================
        #-----------------------------------------------------------------------
        
        #=-----------------------------------------------------------------------
        ''''baba begin '''
        #-----------------------------------------------------------------------
        self.ReadShp.clicked.connect(self.readshp) #def readshp(self):
        self.ReadExcel.clicked.connect(self.readexcel) #def readexcel(self):
        self.ReadIn.clicked.connect(self.readin) #def readin(self):
        self.ReadOut.clicked.connect(self.readout) #def readout(self):
        self.InpButton.clicked.connect(self.interpolation) #def interpolation(self):

        ''''baba end '''

    '''functions'''



    '''baba begin'''
    '''click ReadShp:
    ----------show file path--------------------------------------'''
    def readshp(self):
        #===============open shapefile====================
        shpfilePath, shpfiletype = QtWidgets.QFileDialog.getOpenFileName(self, "Select File", "./","*.shp")
        #==================print filename===============
        self.ReadShpText.setText(shpfilePath)
        test = gdalrw.ShapeReadWrite()
        result_list = test.readShp(shpfilePath)
        test.read_shp(shpfilePath)
        print("OK")
    '''click ReadExcel:
    ----------show file path--------------------------------------'''
    def readexcel(self):
        #===============open shapefile====================
        excelfilePath, excelfiletype = QtWidgets.QFileDialog.getOpenFileName(self, "Select File", "./","*.*")
        #==================print filename===============
        self.ReadExcelText.setText(excelfilePath)
    '''click ReadIn:
    ----------show file path--------------------------------------'''
    def readin(self):
        #===============open shapefile====================
        infilePath, infiletype = QtWidgets.QFileDialog.getOpenFileName(self, "Select File", "./","*.*")
        #==================print filename===============
        self.ReadInText.setText(infilePath)
    '''click ReadOut:
    ----------show file path--------------------------------------'''
    def readout(self):
        #===============open shapefile====================
        outfilePath = QtWidgets.QFileDialog.getExistingDirectory(self, "Select FilePath")
        #==================print filename===============
        self.ReadOutText.setText(outfilePath)
    def interpolation(self):
        idw.idwmain(self.ReadExcelText.toPlainText(), self.ReadInText.toPlainText(), self.ReadOutText.toPlainText()+'/')
    '''baba end'''

        
      



'''-----------------------------------------------------------------------------------------------
============main==================main==========================main===========================
-----------------------------------------------------------------------------------------------'''
if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    mywindow = Windowinterp_yzy()
    mywindow.show()
    sys.exit(app.exec_())