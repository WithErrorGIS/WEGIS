'''Class slopeCal:
calculate slope from input raster data'''

import numpy as np
import math
from osgeo import gdal,ogr,osr



def Cacdxdy(npgrid,sizex,sizey):
 
    nx, ny = npgrid.shape
    s_dx = np.zeros((nx,ny))
    s_dy = np.zeros((nx,ny))

    #gradient
    for i in range(1,nx-1):
        for j in range(1,ny-1):
            s_dx[i,j] = ((npgrid[i-1,j+1]+2*npgrid[i,j+1]+npgrid[i+1,j+1])-(npgrid[i-1,j-1]+2*npgrid[i,j-1]+npgrid[i+1,j-1])) / (8 * sizex)
            s_dy[i, j] = ((npgrid[i+1, j-1] + 2 * npgrid[i+1, j] + npgrid[i+1,j+1])-(npgrid[i-1,j-1]+2 * npgrid[i-1,j] + npgrid[i-1,j+1])) / (8 * sizey)
            
    #save origional extent
    s_dx = s_dx[1:-1,1:-1]
    s_dy = s_dy[1:-1,1:-1]

    slope=(np.arctan(np.sqrt(s_dx*s_dx+s_dy*s_dy)))*180/math.pi #unit: degree

    return slope



