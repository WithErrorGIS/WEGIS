'''
    variogram
'''
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit


class point:
    def __init__(self,x,y,value):
        self.x=x
        self.y=y
        self.value=value

class gamapoint:
    def __init__(self,dst,gam):
        self.dst=dst
        self.gam=gam

'''
distance
'''
class CalDistance():
    def __init__(self,pt1,pt2):
        self.pt1 = pt1
        self.pt2 = pt2
        
    def dist(self):
        dx=self.pt1.x-self.pt2.x
        dy=self.pt1.y-self.pt2.y
        return math.sqrt(dx**2+dy**2)

'''
Semi-variation function
'''

def gamma(num,pt1,pt2):
    tmp1=1.0/(2.0*num)
    tmp0=0
    tmp2=pt1.value-pt2.value
    tmp0=tmp0+tmp2**2
    return tmp1*tmp0


def getVarPts(pts):
    dst=[]
    gam=[]
    num=len(pts)
    for i in range(0,len(pts)):
        for j in range(0,len(pts)):
            if (i!=j):
                dis = CalDistance(pts[i],pts[j])
                distance= dis.dist()
                gamm=gamma(num,pts[i],pts[j])

                if(gamm>(1.0/100)*distance):
                    dst.append(round(distance,2))
                    gam.append(round(gamm,3))
    return dst,gam
                

'''
read data from csv
'''


def readTmin(inputFilename):
    xs=[]
    ys=[]
    values=[]
    points=[]
    f=open(inputFilename,"r")
    lines=f.readlines()
    for rd_line in lines:
        line=rd_line.strip("\n").split(",")
        xs.append(line[1])
        ys.append(line[2])
        values.append(line[3])
    
    for i in range(1,len(xs)):  #注意这里跳过了第一行表头
        poi=point(float(xs[i]),float(ys[i]),float(values[i]))
        #poi.x=xs[i]
        #poi.y=ys[i]
        #poi.value=values[i]
        points.append(poi)
    return points

'''
plot original data
'''
def plot_original(dst, gam):
    plot1=plt.plot(dst, gam, '*',label='original values')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend(loc=4)
    plt.title('ORIGIN VALUES')
    plt.show()

def calVario(fileName):
    points = readTmin(fileName)
    dst,gam = getVarPts(points)
    plot_original(dst, gam)

