import sys
from PyQt5.QtWidgets import QMessageBox, QDialogButtonBox
from PyQt5 import QtCore, QtSql
from WEGIS.develop.UI.DatabasemMainWindow import Ui_DataBaseMainWindow
from PyQt5.QtSql import QSqlDatabase, QSqlQuery
from WEGIS.develop.UI.NewDBDialog import Ui_newdbDialog
from WEGIS.develop.UI.ConnectDBDialog import Ui_connectdbDialog
import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
from PyQt5.QtWidgets import QApplication, QComboBox, QFormLayout, QLineEdit, QMainWindow, QDialog


class DatabaseWindow(QMainWindow, Ui_DataBaseMainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.newdbButton.clicked.connect(self.create_db)
        self.connectButton.clicked.connect(self.connect_db)
        self.browseButton.clicked.connect(self.view_data)
        self.Newdb = NewdbDialog()
        self.status = self.statusBar()
        self.status.showMessage('请连接数据库', 0)
        self.Connectdb = ConnectdbDialog()
        self.name = None
        self.host = None
        self.port = None
        self.bd = None
        self.username = None
        self.PWD = None
        self.connection = None
        self.Newdb._signal.connect(self.get_db_info)
        self.Connectdb._signal.connect(self.get_db_info)
        self.newlayerButton.clicked.connect(self.add_row_data2)
        self.deleteButton.clicked.connect(self.del_row_data)
        self.removebdButton.clicked.connect(self.remove_db_connection)

    def get_db_info(self, name, host, port, bd, user, pwd):
        self.name = name
        self.host = host
        self.port = port
        self.bd = bd
        self.username = user
        self.PWD = pwd

        print(self.name, self.host, self.port, )

    def create_db(self):
        self.Newdb.exec_()
        self.status.showMessage('连接数据库准备', 0)

        try:
            conn = psycopg2.connect(database="postgres", port=self.port, host=self.host, user=self.username,
                                    password=self.PWD)
            # conn = psycopg2.connect(database="postgres", port=5432, host='localhost', user='postgres', password='RSLrsl123')

            conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)

            cursor = conn.cursor()
            cursor.execute("CREATE DATABASE {}".format(self.bd))

            conn = psycopg2.connect(database=self.bd, port=self.port, host=self.host, user=self.username,
                                    password=self.PWD)
            cursor = conn.cursor()
            cursor.execute(
                "create extension postgis;"
                "CREATE TABLE POLYGON_Layer (FID SERIAL PRIMARY KEY,layer_ID BIGINT NOT NULL,polygon_ID BIGINT NOT NULL,polygon_label VARCHAR(255),polygon_self_attributeValue VARCHAR(255),polygon GEOMETRY(POLYGON, 26910));"
                "CREATE TABLE LINE_Layer (FID SERIAL PRIMARY KEY,layer_ID BIGINT NOT NULL,line_ID BIGINT NOT NULL,line_label VARCHAR(255),line_self_attributeValue VARCHAR(255),line GEOMETRY(LINESTRING, 26910));"
                "CREATE TABLE POINT_Layer (FID SERIAL PRIMARY KEY,layer_ID BIGINT NOT NULL,point_ID BIGINT NOT NULL,point_label VARCHAR(255),point_self_attributeValue VARCHAR(255),geom GEOMETRY(Point, 26910));"
                "CREATE TABLE Layer (FID SERIAL PRIMARY KEY,layer_Name CHAR(900) NOT NULL UNIQUE,Shape_Type CHAR(600) NOT NULL,Other_info VARCHAR(255));")
            conn.commit()
            QMessageBox.information(self, "成功", "创建数据库成功", QMessageBox.Yes)
            self.status.showMessage('成功创建' + self.bd + '数据库', 2000)


        except Exception as e:
            print(str(e))
            QMessageBox.critical(self, "错误", str(e))

    def connect_db(self):

        self.Connectdb.exec_()
        try:
            db = QSqlDatabase("QPSQL")
            db.setUserName(self.username)  # postgres is the default root username
            db.setPassword(self.PWD)
            db.setHostName(self.host)
            db.setPort(int(self.port))
            db.setDatabaseName(self.bd)

            if db.open():
                self.connection = db
                QMessageBox.information(self, "成功", "已经连接" + self.bd + "数据库", QMessageBox.Yes)
                self.status.showMessage('成功连接' + self.bd + '数据库', 0)
                print(db.open())
            else:
                QMessageBox.critical(self, "失败", "请检查")


        except Exception as e:
            print(str(e))
            QMessageBox.critical(self, "错误", str(e))

            # conn = psycopg2.connect(database=self.bd, port=self.port, host=self.host, user=self.username,
            #                         password=self.PWD)
            # self.cursor = conn.cursor()

    def view_data(self):
        db = QSqlDatabase.addDatabase("QPSQL")
        db.setUserName("postgres")  # postgres is the default root username
        db.setPassword('RSLrsl123')
        db.setHostName('localhost')
        db.setPort(5432)
        db.setDatabaseName('wegis')
        print(db.open())
        self.connection = db
        self.model = QtSql.QSqlTableModel()
        self.dbtableView.setModel(self.model)

        self.model.setTable("layer")
        self.model.setEditStrategy(QtSql.QSqlTableModel.OnManualSubmit)  # 允许字段更改
        self.model.select()
        # self.model.setHeaderData(0, QtCore.Qt.Horizontal, "GID")
        # self.model.setHeaderData(1, QtCore.Qt.Horizontal, "ID")
        self.dbtableView.setColumnHidden(0, True)

    def add_row_data(self):
        # 如果存在实例化的数据模型对象
        if self.model:
            self.model.insertRows(self.model.rowCount(), 1)
            self.model.submit()

        else:
            self.connect_db()

    def del_row_data(self):
        if self.model:
            del_name = self.dbtableView.currentIndex().data()
            query = QSqlQuery()
            query_ok_1=query.exec("DELETE FROM layer WHERE layer_name = '{}';"
                       "DROP TABLE {}".format(del_name, del_name))
            print(del_name)
            if not query_ok_1:
                QMessageBox.warning(self, "失败", query.lastError().text())
            else:
                self.model.select()

        else:
            self.connect_db()

    def remove_db_connection(self):
        if self.model:
            self.model.clear()
        if self.connection.open():
            self.connection.close()
            self.status.showMessage('移除成功，请连接数据库', 0)

    def add_row_data2(self):
        """
        用来获取需要做曲线的两个Item, 也可以做多个
        :return:
        """
        dialog = QDialog(self)  # 自定义一个dialog

        formLayout = QFormLayout(dialog)  # 配置layout
        items = ['POINT', 'LINE', 'POLYGON']
        lineEdit1 = QLineEdit()
        formLayout.addRow('图层名称', lineEdit1)
        lineEdit2 = QLineEdit()
        formLayout.addRow('其他信息', lineEdit2)

        comboBox1 = QComboBox()
        comboBox1.addItems(items)  # 第一个做曲线的通道名称
        formLayout.addRow('要素类型', comboBox1)

        # comboBox1.setCurrentText(self.ChoosedColumnName.currentText())
        # StartX = QSpinBox()
        # StartX.setMaximum(100_0000)
        # StepX = QSpinBox()
        # StepX.setMaximum(100_0000)
        # formLayout.addRow('Start', StartX)
        # formLayout.addRow('Step ', StepX)
        button = QDialogButtonBox(QDialogButtonBox.Ok)
        formLayout.addRow(button)
        button.clicked.connect(dialog.accept)
        dialog.show()



        if dialog.exec_() == QDialog.Accepted:
            new_layer_dic = {
                'POINT': "CREATE TABLE {} (FID SERIAL PRIMARY KEY,layer_ID BIGINT NOT NULL,point_ID BIGINT NOT NULL,point_label VARCHAR(255),point_self_attributeValue VARCHAR(255),geom GEOMETRY(Point, 26910));".format(
                    lineEdit1.text()),
                'LINE': "CREATE TABLE {} (FID SERIAL PRIMARY KEY,layer_ID BIGINT NOT NULL,line_ID BIGINT NOT NULL,line_label VARCHAR(255),line_self_attributeValue VARCHAR(255),line GEOMETRY(LINESTRING, 26910));".format(
                    lineEdit1.text()),
                'POLYGON': "CREATE TABLE {} (FID SERIAL PRIMARY KEY,layer_ID BIGINT NOT NULL,polygon_ID BIGINT NOT NULL,polygon_label VARCHAR(255),polygon_self_attributeValue VARCHAR(255),polygon GEOMETRY(POLYGON, 26910));".format(
                    lineEdit1.text()),
            }

            query = QSqlQuery()
            query.exec("SELECT MAX(fid) FROM layer")
            query.next()
            if query.value(0) != None:
                primary_key = query.value(0) + 1
                print(primary_key)
            query_ok_1 = query.exec(
                "{} insert into layer(fid,layer_name,shape_type,other_info) values({},'{}','{}','{}')".format(
                    new_layer_dic[comboBox1.currentText()], primary_key, lineEdit1.text(), comboBox1.currentText(),
                    lineEdit2.text()))
            # query_ok_2 = query.exec()
            # print("{} insert into layer(fid,layer_name,shape_type,other_info) values({},'{}','{}','{}')".format(new_layer_dic[comboBox1.currentText()],primary_key,lineEdit1.text(),comboBox1.currentText(),lineEdit2.text()))
            if not query_ok_1:
                QMessageBox.warning(self, "失败", query.lastError().text())
            else:
                QMessageBox.information(self, "成功", "新建图层成功", QMessageBox.Yes)
                self.model.select()
            return comboBox1.currentText(), lineEdit1.text(), lineEdit2.text()

        else:
            return ()





class ConnectdbDialog(QDialog, Ui_connectdbDialog):
    _signal = QtCore.pyqtSignal(str, str, str, str, str, str)  # 声明信号

    def __init__(self):
        super(ConnectdbDialog, self).__init__()
        self.setupUi(self)
        self.retranslateUi(self)
        self.connectdbBox.accepted.connect(self.slot1)
        self.connectdbBox.rejected.connect(self.close)

    def slot1(self):
        cdbName = self.cdbNamelineEdit.text()
        cdbHost = self.cdbHostlineEdit.text()
        cdbPort = self.cdbPortlineEdit.text()
        cdbDB = self.cdbDBlineEdit.text()
        cdbUser = self.cdbUserNamelineEdit.text()
        cdbPWD = self.cdbPWDlineEdit.text()

        self._signal.emit(cdbName, cdbHost, cdbPort, cdbDB, cdbUser, cdbPWD)
        self.close()


class NewdbDialog(QDialog, Ui_newdbDialog):
    _signal = QtCore.pyqtSignal(str, str, str, str, str, str)  # 声明信号

    def __init__(self):
        super(NewdbDialog, self).__init__()
        self.setupUi(self)
        self.retranslateUi(self)
        self.newdbBox.accepted.connect(self.slot1)
        self.newdbBox.rejected.connect(self.close)

    def slot1(self):
        ndbName = self.ndbNamelineEdit.text()
        ndbHost = self.ndbHostlineEdit.text()
        ndbPort = self.ndbPortlineEdit.text()
        ndbDB = self.ndbDBlineEdit.text()
        ndbUser = self.ndbUserNamelineEdit.text()
        ndbPWD = self.ndbPWDlineEdit.text()
        self._signal.emit(ndbName, ndbHost, ndbPort, ndbDB, ndbUser, ndbPWD)
        self.close()
if __name__ == '__main__':
    app = QApplication(sys.argv)
    DatabaseWindow = DatabaseWindow()
    DatabaseWindow.show()
    sys.exit(app.exec_())