import xlrd
import numpy as np
import math
from scipy.optimize import leastsq
import time
import matplotlib.pyplot as plt   


# Class Point usd to store a single point 
class Point:
    def __init__(self, id, x, y, z, name, rain):
        self.X = float(x)
        self.Y = float(y)
        self.Z = float(z)
        self.ID = int(id)
        self.name = name
        self.rain = float(rain)

# a single day structure day, month, and year are string
class date:
    def __init__(self, year, month, day, Points):
        self.year = year
        self.month = month
        self.day = day
        self.points = Points

def distance(A, B):
    '''Return the 2D distance of two points A, B'''
    return math.sqrt((A.X - B.X)**2 + (A.Y - B.Y)**2)

# read data in excel and return records in the form of days
def ReadExcel(ExcelFilePath):
    ExcelFile = xlrd.open_workbook(ExcelFilePath)
    sheet = ExcelFile.sheet_by_index(0)

    days = []

    for i in range(6, sheet.nrows):
        points = []
        if sheet.row(i)[0].value is not None:
            year = str(int(sheet.row(i)[0].value))
            month = str(int(sheet.row(i)[1].value))
            day = str(int(sheet.row(i)[2].value))
            for j in range(6, 15):
                if sheet.row(i)[j].value != -9999 and sheet.row(i)[j].value is not "":
                    point = Point(sheet.row(1)[j].value, sheet.row(3)[j].value, sheet.row(4)[j].value,
                                  sheet.row(5)[j].value, sheet.row(2)[j].value, sheet.row(i)[j].value)
                    points.append(point)
            if len(points) > 0:
                days.append(date(year, month, day, points))
    return days

def func(p, x):
    '''The function need to be fit, linear'''
    k, b = p
    return k * x + b

def error(p, x, y):
    '''Function error: x, y are all list, in correspondece with Xi, Yi'''
    return func(p, x) - y

def CalculateCoefficient(Records):
    '''Calculate twelve Coefficient in correspondece with twelve month'''
    # Append record by month
    lists = [[] for i in range(12)]
    for record in Records:
        for point in record.points:
            lists[int(record.month) - 1].append(point)
    listCeofficiet = []

    for list in lists:
        zlist = []
        plist = []

        for i in range(len(list)):
            for j in range(i, len(list)):
                p1 = list[i]
                p2 = list[j]
                if p1.rain != 0 and p2.rain != 0 and p1.rain != -9999 and p2.rain != -9999:
                    zlist.append(p1.Z - p2.Z)
                    plist.append((p1.rain - p2.rain) / (p1.rain + p2.rain))

        zarray = np.array(zlist)
        parray = np.array(plist)

        # least square method
        Para = leastsq(error, np.array([1, 2]), args=(zarray, parray))

        listCeofficiet.append([Para[0][0], Para[0][1]])
        # like y = k * x + b
        print("y = "+ str(Para[0][0]) +"* x +" + str(Para[0][1]))
    return listCeofficiet


# Unifing elevation To Z0
def TransferToZ0(Records,Z0,listCeofficiet):
    for record in Records:
        for poi in record.points:
            x_Z_Z0 = listCeofficiet[int(record.month) - 1][0] * ( Z0 - poi.Z )
            poi.rain = poi.rain * ((1 + x_Z_Z0) / (1 - x_Z_Z0))

def GetAltitude(demfilename):
    # read elevation
    f = open(demfilename, "r")
    # skip head
    for i in range(6):
        f.readline()
    AltiList = []
    flines = f.readlines()
    for fline in flines:
        linelist = fline.split()
        AltiList.append(linelist)
    return AltiList

# IDW Aigorithm
def IDWInterpo(record,p0):
    Numerator = 0.0
    denominator = 0.0
    for poi in record.points:
        Numerator += poi.rain * (1 / distance(poi, p0))
        denominator += (1 / distance(poi, p0))
    return Numerator / denominator    

def InterpoOutput(saveDir,Records,AltiList,listCeofficiet,Z0):
    
    # information in raster
    ncols = 233
    nrows = 153
    xllcorner = 457072.15189873
    yllcorner = 4177612.1
    cellsize = 1000
    NODATA_value = -9999
    # start coordinate
    xstart = xllcorner + cellsize / 2
    ystart = yllcorner + cellsize / 2
    
    
    t=int(time.time())
    for record in Records:
        savePath = saveDir + str(record.year) + "_" + str(record.month) + "_" + str(record.day) + ".asc"
        ff = open(savePath, "w")
        ff.write("ncols " + str(ncols) + "\n")
        ff.write("nrows " + str(nrows) + "\n")
        ff.write("xllcorner " + str(xllcorner) + "\n")
        ff.write("yllcorner " + str(yllcorner) + "\n")
        ff.write("cellsize " + str(cellsize) + "\n")
        ff.write("NODATA_value " + str(NODATA_value) + "\n")

        ID = 1
        # calculate current piosition
        for row in range(nrows, 0, -1):
            for col in range(ncols):
                z = AltiList[nrows - row][col]
                # print type(z)
                if z == str(NODATA_value) or z == NODATA_value:
                    ff.write(str(NODATA_value) + " ")
                else:
                    x = col * cellsize + xstart
                    y = (row - 1) * cellsize + ystart

                    p0 = Point(ID, x, y, z, "", -1)
                    ID = ID + 1
                    
                    # get rain on elevation of z0 at position p0 
                    Z0rain = IDWInterpo(record,p0)

                    # print z0
                    x_Z_Z0=listCeofficiet[int(record.month)-1][0]*(p0.Z-Z0)+listCeofficiet[int(record.month)-1][1]
                    # z0rain to z rain
                    p0.rain = Z0rain * ((1 + x_Z_Z0) / (1 - x_Z_Z0))
                    ff.write(str(p0.rain) + " ")
            ff.write("\n")
        ff.close()
    print("total time cost:",int(time.time())-t,"s")


def idwmain(excelpath,Demfilename,saveDir):
    # information in raster
    '''
    ncols = 233
    nrows = 153
    xllcorner = 457072.15189873
    yllcorner = 4177612.1
    cellsize = 1000
    NODATA_value = -9999
    # start coordinate
    xstart = xllcorner + cellsize / 2
    ystart = yllcorner + cellsize / 2
    '''
    #excelpath = "D:\\grade3_dsktp\\junior\\GIS algorithm\\1117\\dailydata_precp.xls"
    #Demfilename = "D:\\grade3_dsktp\\junior\\GIS algorithm\\1117\\data\\dem.txt"
    #saveDir = "D:\\grade3_dsktp\\junior\\GIS algorithm\\1117\\result\\"

    # read data in excel and return records in the form of days
    Records = ReadExcel(excelpath)

    # calculate Ceofficiet and pu them in the list
    listCeofficiet = CalculateCoefficient(Records)

    # Unifing elevation To Z0
    Z0 = 2000
    TransferToZ0(Records,Z0,listCeofficiet)
    # Get cliped dem
    AltiList = GetAltitude(Demfilename)
    # interpolation
    InterpoOutput(saveDir,Records,AltiList,listCeofficiet,Z0)

    print("Done!")


if __name__ == '__main__':
# information in raster
    ncols = 233
    nrows = 153
    xllcorner = 457072.15189873
    yllcorner = 4177612.1
    cellsize = 1000
    NODATA_value = -9999
# start coordinate
    xstart = xllcorner + cellsize / 2
    ystart = yllcorner + cellsize / 2

    excelpath = "D:\\grade3_dsktp\\junior\\GIS algorithm\\1117\\dailydata_precp.xls"
    Demfilename = "D:\\grade3_dsktp\\junior\\GIS algorithm\\1117\\data\\dem.txt"
    saveDir = "D:\\grade3_dsktp\\junior\\GIS algorithm\\1117\\result\\"

# read data in excel and return records in the form of days
    Records = ReadExcel(excelpath)

# calculate Ceofficiet and pu them in the list
    listCeofficiet = CalculateCoefficient()

# Unifing elevation To Z0
    Z0 = 2000
    TransferToZ0(Records,Z0)
# Get cliped dem
    AltiList = GetAltitude(Demfilename)
# interpolation
    InterpoOutput(saveDir)

    print("Done!")

