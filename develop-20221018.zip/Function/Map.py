'''
地图类别，可以认为是多个图层组成的容器，相当于一个工程
一个工程里面有统一的显示范围、比例尺、……
'''

from .Layer import *
from .Geometry import *


class Map(object):
    def __init__(self):
        self.layers = []            # 图层集合。下标0为最顶层
        self.offsetX = 0            # 显示区域中心的X地理坐标
        self.offsetY = 0            # 显示区域中心的Y地理坐标
        self.scale = 1              # 地图缩小系数（即比例尺为1:scale），scale越大几何体越小
        self.box = MBR()     # 全地图的外包矩形
        self.selectedLayer = -1     # 选定图层的下标，默认为-1，即未选择图层

    def AddLayer(self, layer, pos=0):
        '''
        添加一个图层，默认在最顶上
        :param layer: 图层Layer对象
        :param pos: 图层的位置，0为最顶层
        '''
        self.layers.insert(pos, layer)
        self.selectedLayer = pos
        #self.RefreshBox() #ZYH1006: 还没实现，所以注释掉了

    # ZYH1006还没做
    def DelLayer(self, index):
        '''删除指定下标的图层'''
        self.layers.pop(index)
        # 删除被选择的图层，默认将被选择图层转为最顶层
        if self.selectedLayer == index:
            self.selectedLayer = 0 if len(self.layers) > 0 else -1
        elif self.selectedLayer > index:
            self.selectedLayer -= 1
        #self.RefreshBox() #ZYH1006: 还没实现，所以注释掉了

    # ZYH1006还没做
    def ClearLayers(self):
        '''清除所有图层'''
        self.layers.clear()
        self.selectedLayer = -1

    def UpdateLayers(self):
        pass

    def RefreshBox(self):
        pass

    def GeoToScreen(self, geometry, screenSize):
        pass

    def ScreenToGeo(self, geometry, screenSize):
        pass

    def FullScreen(self, width, height):
        pass

    def ZoomAtPoint(self, screenSize, point, newScale):
        pass