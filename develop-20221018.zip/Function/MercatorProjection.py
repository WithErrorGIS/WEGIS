import math
import os
from osgeo import gdal
import geopandas as gpd
import json
from shapely.geometry import Point
from shapely import geometry

class parameters:
    class const_54:
        a=6378245.0
        sqe=0.006693421622966
        e=math.sqrt(sqe)
        sqe2=0.006738525414683
        b=6356863.02
    
    class const_mct:
        lat0=0.0
        lon0=0.0
    
    class params:
        @staticmethod
        def k(lat0):
            temp1=1.0+parameters.const_54.sqe2*math.cos(lat0)*math.cos(lat0)
            temp2=math.cos(lat0)/math.sqrt(temp1)
            return (parameters.const_54.a*parameters.const_54.a*temp2)/parameters.const_54.b
        
class project:
    @staticmethod
    def x(k,phi):
        e1=parameters.const_54.e
        temp1=math.pow((1-e1*math.sin(phi))/(1+e1*math.sin(phi)),e1/2)
        temp2=math.log(temp1*math.tan(math.pi/4+phi/2))
        return k*temp2

    @staticmethod
    def y(k,lamda):
        return k*(lamda-parameters.const_mct.lon0)

class inverse:
    @staticmethod
    def lgt(y,k):
        return y/k+parameters.const_mct.lon0

    @staticmethod
    def ltt(x,k):
        b0=0
        b1=0
        e=parameters.const_54.e
        while True:
            b0=b1
            temp1=math.log((1-e*math.sin(b0))/(1+e*math.sin(b0)))
            temp2=math.exp(e/2*temp1)
            temp3=math.exp(-x/k)
            b1=math.pi/2-2*math.atan(temp2*temp3)
            if math.fabs(b0-b1)<1e-5:
                break
        return b1

class testing:
    @staticmethod
    def transform(phi,lamda):
        k1=parameters.params.k(parameters.const_mct.lat0)
        t_x=project.x(k1,phi)
        t_y=project.y(k1,lamda)
        return [t_y,t_x]
    
    @staticmethod
    def inv(y,x):
        k1=parameters.params.k(parameters.const_mct.lat0)
        i_lat=inverse.ltt(x,k1)*180/math.pi
        i_lon=inverse.lgt(y,k1)*180/math.pi
        return (i_lon,i_lat)
    

    #-------------------projection function
    #======================================================
    def projtionMec(gdf):

        projected_all=[]

        #get geometry vertices coordiantes
        for index, row in gdf.iterrows():
            multi = row.geometry.type.startswith("Multi") #check if multi

            if multi:
                projected_part=[]
                # iterate over all parts of multigeometry
                for part in row.geometry:
                    corrdver=part.exterior.coords
                    prjedpoints=[]
                    for pt in list(corrdver):
                        phi=(pt[1]/360)*2*math.pi
                        lamda=(pt[0]/360)*2*math.pi
                        Eprj,Nprj=testing.transform(phi,lamda) #projecting
                        prjedpoints.append(geometry.Point(Eprj,Nprj))
                    projected_part.append(geometry.Polygon(prjedpoints))
            

            else:
                prjedpoints=[]
                for pt in list(row['geometry'].exterior.coords):
                    phi=(pt[1]/360)*2*math.pi
                    lamda=(pt[0]/360)*2*math.pi
                    Eprj,Nprj=testing.transform(phi,lamda) #projecting
                    prjedpoints.append(geometry.Point(Eprj,Nprj))
                projected_all.append(geometry.Polygon(prjedpoints))
        

        return projected_all

