'''
树形控件的相关操作函数
'''
from PyQt5.QtWidgets import QTreeWidget, QTreeWidgetItem, QMenu,QAbstractItemView, QMessageBox
from PyQt5.QtGui import QIcon, QCursor,QFont
from PyQt5.QtCore import Qt
from .Layer import Layer
from .Geometry import *

# ZYH1017：图层树管理类
class LayerTree(QTreeWidget):
    def updateTree(self,LayerList):
        # 删除所有树节点
        root_idx = self.topLevelItemCount()
        for i in range(0, root_idx):
            # 删除节点，是实时的，所以永远删除第一个节点，相当于从list中pop
            self.takeTopLevelItem(0)

        self.setHeaderLabels(['Layers in WEGIS'])
        # 设置图层树的根节点
        self.root = QTreeWidgetItem(self)
        self.root.setText(0, '示例地图')

        for layer in LayerList:
            # 将所有图层添加至子节点
            child = QTreeWidgetItem(self.root)
            # 注意，图层树里不显示标识符！！
            child.setText(0, layer.name.split('-')[0])
            self.root.addChild(child)
            print('debug')
        self.expandAll()  # 展开所有图层树节点