'''calculate flow direction using the D8 algorithm'''
from sys import base_prefix
import numpy as np
import math

'''calculate grids not on the four corners and sides of the raster
position: (m,n)'''
def calDir(dataMatrix,m,n):
    dir=-1
    x=[None]*8
    x[0] = dataMatrix[m, n] - dataMatrix[m, n + 1]
    x[2] = dataMatrix[m, n] - dataMatrix[m + 1, n]
    x[4] = dataMatrix[m, n] - dataMatrix[m, n - 1]
    x[6] = dataMatrix[m, n] - dataMatrix[m - 1, n]
    x[1] = (dataMatrix[m, n] - dataMatrix[m + 1, n + 1]) / 1.4142
    x[3] = (dataMatrix[m, n] - dataMatrix[m + 1, n - 1]) / 1.4142
    x[5] = (dataMatrix[m, n] - dataMatrix[m - 1, n - 1]) / 1.4142
    x[7] = (dataMatrix[m, n] - dataMatrix[m - 1, n + 1]) / 1.4142

    #comparison and decide direction
    if (x[0] >= 0):
        dir = 0
    for i in (1,7):
        if (x[i] < 0):
            dir=dir
        elif (x[i] > x[i-1]):
            dir = i
    
    return (2**dir)

'''calculate grids on the four sides of the raster'''
def calDirsid(dataMatrix,m,n,nrow,ncol):
    borderType=-1
    dir=-1
    x=[None]*5

    #which side
    if (n==0): #left side 6,7,0,1,2 direction
        borderType=3
        x[0] = dataMatrix[m, n] - dataMatrix[m - 1, n]
        x[1] = (dataMatrix[m, n] - dataMatrix[m - 1, n + 1]) / 1.4142
        x[2] = dataMatrix[m, n] - dataMatrix[m, n + 1]
        x[3] = x[1] = (dataMatrix[m, n] - dataMatrix[m + 1, n + 1]) / 1.4142
        x[4] = dataMatrix[m, n] - dataMatrix[m + 1, n]

    elif (m==0): #upper side 0,1,2,3,4 direction
        borderType = 0
        x[0] = dataMatrix[m, n] - dataMatrix[m, n + 1]
        x[1] = (dataMatrix[m, n] - dataMatrix[m + 1, n + 1]) / 1.4142
        x[2] = dataMatrix[m, n] - dataMatrix[m + 1, n]
        x[3] = (dataMatrix[m, n] - dataMatrix[m + 1, n - 1]) / 1.4142
        x[4] = dataMatrix[m, n] - dataMatrix[m, n - 1]

    elif (n==ncol-1):# right side 2,3,4,5,6 direction
        borderType = 1
        x[0] = dataMatrix[m, n] - dataMatrix[m + 1, n]
        x[1] = (dataMatrix[m, n] - dataMatrix[m + 1, n - 1]) / 1.4142
        x[2] = dataMatrix[m, n] - dataMatrix[m, n - 1]
        x[3] = (dataMatrix[m, n] - dataMatrix[m - 1, n - 1]) / 1.4142
        x[4] = dataMatrix[m, n] - dataMatrix[m - 1, n]

    elif (m==nrow-1): #bottom side 4,5,6,7,0 direction
        borderType = 2
        x[0] = dataMatrix[m, n] - dataMatrix[m, n - 1]
        x[1] = (dataMatrix[m, n] - dataMatrix[m - 1, n - 1]) / 1.4142
        x[2] = dataMatrix[m, n] - dataMatrix[m - 1, n]
        x[3] = (dataMatrix[m, n] - dataMatrix[m - 1, n + 1]) / 1.4142
        x[4] = dataMatrix[m, n] - dataMatrix[m, n + 1]
    
    if (x[0] >= 0):
        dir = 2 * borderType
    for i in range (1,5):
        if (x[i] < 0):
            continue
        elif (x[i] > x[i - 1]):
            dir = 2 * borderType + i
    
    #post processing
    if (dir>=8):
        dir=dir-8

    elif (dir==-1):
        if (borderType==0):
            dir=6
        elif (borderType==1):
            dir=0
        elif (borderType==2):
            dir=2
        elif (borderType==3):
            dir=4
    
    return (2**dir)

'''calculate grids on the four corners of the raster'''
def calDircor(dataMatrix,m,n):
    cornerType=-1
    dir=-1
    x=[None]*3

    #which corner
    if ((m == 0) & (n == 0)): #upper left 0,1,2 direction
        cornerType = 0
        x[0] = dataMatrix[m, n] - dataMatrix[m, n + 1]
        x[1] = (dataMatrix[m, n] - dataMatrix[m + 1, n + 1]) / 1.4142
        x[2] = dataMatrix[m, n] - dataMatrix[m + 1, n]

    elif ((m == 0) & (n != 0)): #upper right
        cornerType = 1
        x[0] = dataMatrix[m, n] - dataMatrix[m + 1, n]
        x[1] = (dataMatrix[m, n] - dataMatrix[m + 1, n - 1]) / 1.4142
        x[2] = dataMatrix[m, n] - dataMatrix[m, n - 1]

    elif ((m != 0) & (n == 0)): #lower left
        cornerType = 3
        x[0] = dataMatrix[m, n] - dataMatrix[m - 1, n]
        x[1] = (dataMatrix[m, n] - dataMatrix[m - 1, n + 1]) / 1.4142
        x[2] = dataMatrix[m, n] - dataMatrix[m, n + 1]

    elif ((m != 0) & (n != 0)):
        cornerType = 2
        x[0] = dataMatrix[m, n] - dataMatrix[m, n - 1]
        x[1] = (dataMatrix[m, n] - dataMatrix[m - 1, n - 1]) / 1.4142
        x[2] = dataMatrix[m, n] - dataMatrix[m - 1, n]
    
    #compare and decide
    if (x[0] >= 0):
        dir = 2 * cornerType
    for i in range (1,3):
        if (x[i] < 0):
            continue
        elif (x[i] > x[i - 1]):
            dir = 2 * cornerType + i
    
    #postprocessing
    if (dir >= 8):
        dir -= 8
    if (dir == -1):
        if (cornerType==0):
            dir=5
        elif(cornerType==1):
            dir=7
        elif (cornerType==2):
            dir=1
        elif (cornerType==3):
            dir=3
    
    return (2**dir)

def D8all(demgrid,row,column):
    newArray=np.empty([row,column],dtype=int)

    #====================corners==============================
    newArray[0,0]=calDircor(demgrid,0,0)
    newArray[0,column-1]=calDircor(demgrid,0,column-1)
    newArray[row-1,0]=calDircor(demgrid,row-1,0)
    newArray[row-1,column-1]=calDircor(demgrid,row-1,column-1)


    #=============sides======================================
    for i in range(1,row-2):
        newArray[i,0]=calDirsid(demgrid,i,0,row,column)
        newArray[i,column-1]=calDirsid(demgrid,i,column-1,row,column)
    for j in range(1,column-2):
        newArray[0,j]=calDirsid(demgrid,0,j,row,column)
        newArray[row-1,j]=calDirsid(demgrid,row-1,j,row,column)
    
    #======================other grids============================
    for i in range(1,row-2):
        for j in range(1,column-2):
            newArray[i,j]=calDir(demgrid,i,j)
    
    return newArray


