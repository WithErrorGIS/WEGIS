import math
from abc import ABC, abstractmethod
import re
import numpy as np
#最小外接矩形类
class MBR(object):
    def __init__(self,minx=0,miny=0,maxx=0,maxy=0):
        self.MinX=minx
        self.MinY=miny
        self.MaxX=maxx
        self.MaxY=maxy

    # 判断点是否在矩形内，是返回True
    def IsPointOn(self, point):
        return point.X>=self.MinX and point.Y>=self.MinY and point.X<=self.MaxX and point.Y<=self.MaxY

    # 判断两个矩形是否相交
    def IsIntersectBox(self, box):
        return not (self.MaxX < box.MinX or self.MaxY < box.MinY or
                    self.MinX > box.MaxX or self.MinY > box.MaxY)

    def Expand(self, radius):
        '''
        将矩形按照radius半径扩张，即四个边向外移动radius距离。返回一个新的矩形。
        :param radius: 扩张半径
        :return: 扩张后的矩形
        '''
        return MBR(minx=self.MinX - radius, miny=self.MinY - radius,
                          maxx=self.MaxX + radius, maxy=self.MaxY + radius)

    # 重写print
    def __str__(self):
        return ("Box:\nMinX={}; MinY={}; MaxX={}; MaxY={}".format(self.MinX,self.MinY,self.MaxX,self.MaxY))

class Geometry(ABC):

    # 属性
    def __init__(self, id=-1):
        self._box = MBR() #最小外接矩形
        self.ID=id
        self.gid=id
        # 轮廓颜色、线性、宽度、填充颜色、无、可见性、绑定字段、水平偏移、垂直偏移、字体大小、字体颜色
        # str/int/float/str/int/int/str/int/int/int/str
        self.StyleList=[
            '#f5f500',
            0,
            1.5,
            '#6edda4',
            0,
            0,
            'id',
            0,
            0,
            10,
            '#000000'
        ]

    @property
    def box(self):
        return self._box

    @box.setter
    def box(self,value):
        self._box=value

    # 方法
    # 图像整体平移
    @abstractmethod
    def Move(self,deltaX,deltaY):pass

    # 点选一该Point是否能选中几何体
    @abstractmethod
    def IsPointOn(self,point,BufferDist):pass

    # 框选一该box是否能选中几何体
    @abstractmethod
    def IsIntersectBox(self, box):pass

    # 找到画注记的位置，为几何中心或距离几何中心最近的点
    @abstractmethod
    def MarkPos(self):pass

    # 将几何体转为WKT字符串
    @abstractmethod
    def ToWkt(self):pass

    @abstractmethod
    def GetDistance(self,MouseLocation):pass

    # 私有函数
    @abstractmethod
    def RenewBox(self):pass

    @staticmethod
    def FindMinMaxXY(data): #寻找数据的xy最小最大值，以确定边界
        listX=[]
        listY=[]
        for i in range(len(data)):
            listX.append(data[i].X)
            listY.append(data[i].Y)
        arrX=np.asarray(listX)
        arrY=np.asarray(listY)
        minmaxXY=[arrX.min,arrY.min,arrX.max,arrY.max] #minX,minY,maxX,maxY
        return minmaxXY

    # @staticmethod
    # def FindMinXY(data):
    #     print("data FindMinXY:")
    #     print(data)
    #     minX = data[0].X
    #     minY = data[0].Y
    #     for i in range(len(data)):
    #         if data[i].X < minX:
    #             minX = data[i].X
    #         if data[i].Y < minY:
    #             minY = data[i].Y
    #     outputP = [minX, minY]
    #     return outputP

    @staticmethod
    def IfHasPoint(point,startP,endP):
        """
        :return：True为point向右的射线与(startP, endP)线段相交
        :exception 可以处理平行的情况
        """
        maxY=max(startP.Y,endP.Y)
        minY=min(startP.Y,endP.Y)
        if point.Y>minY and point.Y<=maxY:
            cx=(startP.X-endP.X)/(startP.Y-endP.Y)*(point.Y-endP.Y)+endP.X
            return cx>=point.X
        else:
            return False

    @staticmethod
    def IsLineIntersect(pa1, pa2, pb1, pb2):
        '''
        判断两“线段”是否相交：
        若相交，则线段1的两端点在线段2两侧，同时线段2的两端点在线段1两侧
        算法：向量(OB x OA)(OC x OA) < 0，则B、C两点在OA两侧
        '''
        z1 = (pb1.X - pa1.X) * (pa2.Y - pa1.Y) - (pa2.X - pa1.X) * (pb1.Y - pa1.Y)
        z2 = (pb2.X - pa1.X) * (pa2.Y - pa1.Y) - (pa2.X - pa1.X) * (pb2.Y - pa1.Y)
        z3 = (pa1.X - pb1.X) * (pb2.Y - pb1.Y) - (pb2.X - pb1.X) * (pa1.Y - pb1.Y)
        z4 = (pa2.X - pb1.X) * (pb2.Y - pb1.Y) - (pb2.X - pb1.X) * (pa2.Y - pb1.Y)
        return z1 * z2 < 0 and z3 * z4 < 0

# region 子类——点
class Point(Geometry):
    # 属性
    def __init__(self,x=0,y=0,id=-1):
        Geometry.__init__(self,id)
        if type(x)==str:
            wkt_find=re.compile(r'\(\S+ \S+\)')
            find_rslt=wkt_find.findall(x)
            if find_rslt:
                match_rslt=re.match('^\((\S+) (\S+)\)$',find_rslt[0])
                if match_rslt:
                    self.X=float( match_rslt.group(1))
                    self.Y=float(match_rslt.group(2))
            else:
                self.X=0
                self.Y=0
        else:
            self.X=x
            self.Y=y
        self.RenewBox()


    # 方法
    # 点选——缓冲区4*4
    def IsPointOn(self,point,BufferDist):
        buffer_box = self._box.Expand(BufferDist)
        if not buffer_box.IsPointOn(point):
            return False
        if self.GetDistance(point)<=BufferDist:
            return True
        else:
            return False

    def IsIntersectBox(self, box):
        if box.IsPointOn(self):
            return True
        else:
            return False

    def Move(self,deltaX,deltaY):
        self.X+=deltaX
        self.Y+=deltaY
        self.RenewBox()

    def RenewBox(self):
        self._box.MaxX=self._box.MinX=self.X
        self._box.MaxY = self._box.MinY = self.Y

    def MarkPos(self):
        return self

    def GetDistance(self,MouseLocation):
        dis=math.sqrt((MouseLocation.X-self.X)*(MouseLocation.X-self.X)+(MouseLocation.Y-self.Y)*(MouseLocation.Y-self.Y))
        return dis

    # 重写print
    def __str__(self):
        return ("Point:\nX={}; Y={}; ID={}".format(self.X,self.Y,self.ID))

    # 覆盖基类的ToWkt，将几何体转为WKT字符串
    def ToWkt(self):
        wkt=f"POINT({self.X} {self.Y})"
        return wkt

class Line(Geometry):
    # 属性 data是点构成的List
    def __init__(self,Data,id=-1):
        Geometry.__init__(self,id)
        if type(Data)==str:
            wkt_find=re.compile(r'[^\(\)\, ]+ [^\(\)\, ]+')
            find_rslt=wkt_find.findall(Data)
            data=[]
            if find_rslt:
                for p in find_rslt:
                    match_rslt=re.match('^(\S+) (\S+)$',p)
                    if match_rslt:
                        data.append(Point(float( match_rslt.group(1)),float(match_rslt.group(2))))
            self.data=data
        else:
            self.data=Data
        self.RenewBox()


    # 方法
    def IsPointOn(self,point,BufferDist):
        """用盒子判断前要先扩展盒子"""
        buffer = self._box.Expand(BufferDist)
        if buffer.IsPointOn(point):
            point_dis=self.GetDistance(point)
            if point_dis<=BufferDist:
                return True
        return False

    def IsIntersectBox(self, box):
        if not self._box.IsIntersectBox(box):
            return False
        if self._box.MaxX<=box.MaxX and self._box.MaxY<=box.MaxY and self._box.MinX>box.MinX and self._box.MinY>box.MinY:
            return True
        for i in range(len(self.data)):
            if self.data[i].IsIntersectBox(box):
                return True
        # 剩下的可能情形：折线每个端点都不在矩形内，却有可能与矩形相交
        # 这种相交一定会跟矩形的对角线相交
        for i in range(len(self.data) - 1):
            if self.IsLineIntersect(self.data[i], self.data[i + 1],
                               Point(box.MinX, box.MinY), Point(box.MaxX, box.MaxY)) \
                    or self.IsLineIntersect(self.data[i], self.data[i + 1],
                                       Point(box.MaxX, box.MinY), Point(box.MinX, box.MaxY)):
                return True
        return False

    def Move(self,deltaX,deltaY):
        for i in range(len(self.data)):
            self.data[i].X+=deltaX
            self.data[i].Y+=deltaY
        self.RenewBox()

    def RenewBox(self):
        # MaxXY=self.FindMaxXY(self.data)
        # MinXY=self.FindMinXY(self.data)
        minmaxXY=self.FindMinMaxXY(self.data)
        self._box.MaxX=minmaxXY[0]
        self._box.MaxY=minmaxXY[1]
        self._box.MinX=minmaxXY[2]
        self._box.MinY=minmaxXY[3]

    def MarkPos(self):
        return self.data[len(self.data)//2]

    def GetDistance(self,MouseLocation):
        """获取点击点到线的距离"""
        MinDistance=math.sqrt((self.data[0].X-MouseLocation.X)*(self.data[0].X-MouseLocation.X)+(self.data[0].Y-MouseLocation.Y)*(self.data[0].Y-MouseLocation.Y))
        distance1=0
        for i in range(len(self.data)-1):
            a=Point(1,1)
            b=Point(1,1)
            a.X=MouseLocation.X-self.data[i].X
            a.Y=MouseLocation.Y-self.data[i].Y

            b.X=self.data[i+1].X-self.data[i].X
            b.Y=self.data[i+1].Y-self.data[i].Y
            neiji=(a.X*b.X+a.Y*b.Y)
            judge=neiji/(b.X*b.X+b.Y*b.Y)
            if judge<0:
                distance1=math.sqrt(a.X*a.X+a.Y*a.Y)
            elif judge>1:
                distance1=math.sqrt((MouseLocation.X-self.data[i+1].X)*(MouseLocation.X-self.data[i+1].X)+(MouseLocation.Y-self.data[i+1].Y)*(MouseLocation.Y-self.data[i+1].Y))
            else:
                distance1=abs(a.X*b.Y-b.X*a.Y)/math.sqrt(b.X*b.X+b.Y*b.Y)

            if distance1<MinDistance:
                MinDistance=distance1
        return MinDistance

    def __str__(self):
        s='Line:\n'
        for i in range(len(self.data)):
            s+='Point{}({},{})\n'.format(i+1,self.data[i].X,self.data[i].Y)
        return s

    # 覆盖基类的ToWkt，将几何体转为WKT字符串
    def ToWkt(self):
        wkt=f"LINESTRING({','.join([f'{p.X} {p.Y}' for p in self.data])})"
        return wkt

class Polygon(Geometry):
    # 属性 data是点构成的List, 表示多边形的外边界
    # 属性holes是Polygon构成的List（这些Polygon不能再有holes），表示多边形的洞
    def __init__(self,Data,holes=[], id=-1):
        Geometry.__init__(self,id)
        if type(Data)==str:
            wkt_find=re.compile(r'\([^\(\)\, ]+ [^\(\)\, ]+(?:\,[^\(\)\, ]+ [^\(\)\, ]+)+\)')
            # wkt_find=re.compile(r'[^\(\)\, ]+ [^\(\)\, ]+')
            find_rslt=wkt_find.findall(Data)
            data=[]
            holes=[]
            if find_rslt:
                wkt_find_line=re.compile(r'[^\(\)\, ]+ [^\(\)\, ]+')
                find_rslt_line=wkt_find_line.findall(find_rslt[0])
                if find_rslt_line:
                    for p in find_rslt_line:
                        match_rslt=re.match('^(\S+) (\S+)$',p)
                        if match_rslt:
                            data.append(Point(float( match_rslt.group(1)),float(match_rslt.group(2))))
                for hole_line in find_rslt[1:]:
                    find_rslt_line=wkt_find_line.findall(hole_line)
                    hole_data=[]
                    if find_rslt_line:
                        for p in find_rslt_line:
                            match_rslt=re.match('^(\S+) (\S+)$',p)
                            if match_rslt:
                                hole_data.append(Point(float( match_rslt.group(1)),float(match_rslt.group(2))))
                    holes.append(Polygon(hole_data[:-1]))
            # self.data=data[:-1]
            self.data=data #221007 不理解之前的为什么排除掉最后一位，改正过来
            self.holes=holes
        else:
            self.data=Data
            if len(holes) > 0 and not isinstance(holes[0], Polygon):
                holes = [Polygon(part) for part in holes]
            self.holes = holes
        self.RenewBox()


    # 方法
    def IsPointOn(self,point, BufferDist=0):
        """判断点是否在多边形内
            看待测点是否在两点连线之上
            即通过这个点划一条水平射线，看该射线与多边形相交几次
            可以处理平行的情况
        """
        flag = False
        # 先判断是否在多边形外边界内
        if(self._box.IsPointOn(point)):# 先用box判断
            NumOfPointIntersection=0
            for i in range(len(self.data)-1):
                if self.IfHasPoint(point,self.data[i],self.data[i+1]):
                    NumOfPointIntersection+=1
            # 首尾连接线的交点判断
            if self.IfHasPoint(point,self.data[0],self.data[len(self.data)-1]):
                NumOfPointIntersection+=1
            if NumOfPointIntersection%2==1:
                flag = True
                # 判断完外边界，判断内边界
                if self.holes is not None:
                    for hole in self.holes:
                        if hole.IsPointOn(point, BufferDist):
                            flag = False
                            break
        return flag

    def IsIntersectBox(self, box):
        """
        判断矩形是否与多边形相交
        :param box:待判断矩形
        :return:布尔变量
        """
        if not self._box.IsIntersectBox(box):
            return False
        if self._box.MaxX<=box.MaxX and self._box.MaxY<=box.MaxY and self._box.MinX>box.MinX and self._box.MinY>box.MinY:
            return True
        for i in range(len(self.data)):
            if self.data[i].IsIntersectBox(box):return True
        if self.holes is not None:
            for hole in self.holes:
                if not hole.box.IsIntersectBox(box):
                    continue
                for hole_point in hole.data:
                    if hole_point.IsIntersectBox(box):
                        return True
        boxP=[Point(box.MinX,box.MinY),Point(box.MinX,box.MaxY),Point(box.MaxX,box.MinY),Point(box.MaxX,box.MaxY)]
        for i in range(4):
            if self.IsPointOn(boxP[i]):return True
        # 剩下的可能情形：折线每个端点都不在矩形内，却有可能与矩形相交
        # 这种相交一定会跟矩形的对角线相交
        for i in range(len(self.data) - 1):
            if self.IsLineIntersect(self.data[i], self.data[i + 1],
                                    Point(box.MinX, box.MinY), Point(box.MaxX, box.MaxY)) \
                    or self.IsLineIntersect(self.data[i], self.data[i + 1],
                                            Point(box.MaxX, box.MinY), Point(box.MinX, box.MaxY)):
                return True
        return False

    def Move(self,deltaX,deltaY):
        for i in range(len(self.data)):
            self.data[i].X+=deltaX
            self.data[i].Y+=deltaY
        if self.holes is not None:
            for hole in self.holes:
                hole.Move(deltaX, deltaY)
        self.RenewBox()

    def MarkPos(self):
        return Point((self._box.MaxX+self._box.MinX)/2,(self._box.MaxY+self._box.MinY)/2)

    def RenewBox(self):
        if len(self.data) == 0:
            return
        minmaxXY=self.FindMinMaxXY(self.data)
        self._box.MaxX=minmaxXY[0]
        self._box.MaxY=minmaxXY[1]
        self._box.MinX=minmaxXY[2]
        self._box.MinY=minmaxXY[3]
        # MaxXY = self.FindMaxXY(self.data)
        # MinXY = self.FindMinXY(self.data)
        # self._box.MaxX = MaxXY.X
        # self._box.MaxY = MaxXY.Y
        # self._box.MinX = MinXY.X
        # self._box.MinY = MinXY.Y

    def GetDistance(self, MouseLocation):pass

    def __str__(self):
        s='Polygon:\n'
        for i in range(len(self.data)):
            s+='Point{}({},{})\n'.format(i+1,self.data[i].X,self.data[i].Y)
        return s

    # 覆盖基类的ToWkt，将几何体转为WKT字符串
    def ToWkt(self):
        wkt=f"POLYGON(({','.join([f'{p.X} {p.Y}' for p in self.data+[self.data[0]]])}){''.join([',({})'.format(','.join([f'{p.X} {p.Y}' for p in hole.data+[hole.data[0]]])) for hole in self.holes])})"
        return wkt

if __name__=='__main__':
    # pg=Polygon([Point(1,1),Point(1,2),Point(1,3),Point(1,1)],[Polygon([Point(1,1),Point(1,2),Point(1,3),Point(1,1)])])
    # mpg=MultiPolygon([pg,pg])
    # print(mpg.ToWkt())
    pt=Point('POINT(1 2)')
    pl=Line('LINESTRING(1.2 -1,2 2,3 3,)')
    # pd=MultiPolygon('MULTIPOLYGON(((1.2 -1,2 2,3 3,1.2 -1)),((1.2 -1,2 2,3 3,1.2 -1)))')
    pd = Polygon('POLYGON((0 0,10 0,10 10,0 10,0 0), (1 3,5 3,5 1,1 1,1 3))')
    # pd = Polygon('POLYGON ((0 0, 10 0, 10 10, 0 10, 0 0), (1 3, 5 3, 5 1, 1 1, 1 3), (9 9, 9 8, 8 8, 8 9, 9 9))')
    print(pd)
    print(pt)
    print(pl)