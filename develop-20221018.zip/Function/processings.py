'''Class processing:
write to output file'''

import numpy as np
import math
from osgeo import gdal,ogr,osr

'''output result grid'''
def write_img(filename, tar_proj, im_geotrans, im_data, datatype):
 
    #get data type
    if 'int8' in im_data.dtype.name:
        datatype = gdal.GDT_Byte
    elif 'int16' in im_data.dtype.name:
        datatype = gdal.GDT_UInt16
    else:
        datatype = gdal.GDT_Float32
 
    #array shape
    if len(im_data.shape) == 3:
        # im_bands, im_height, im_width
        im_bands, im_height, im_width = im_data.shape
    else:
        im_bands, (im_height, im_width) = 1, im_data.shape
 

    driver = gdal.GetDriverByName("GTiff")
    dataset = driver.Create(filename, im_width, im_height, im_bands, datatype)
 
    dataset.SetGeoTransform(im_geotrans) 
    dataset.SetProjection(tar_proj)
 
    if im_bands == 1:
        dataset.GetRasterBand(1).WriteArray(im_data)  # write output array
    else:
        for i in range(im_bands):
            dataset.GetRasterBand(i + 1).WriteArray(im_data[i])
 
    del dataset
