'''03/10/2022, zy yin, H:/2022/Homework/WEGISsystem/week3
python 3.9.12, pyqt 5.15.4
window form for calculating slope and aspect from input raster
form: SlopeAsp.ui/Ui_SlopeAsp.py
main function: Main_SlopeAsp.py'''

'''input: raster
processing: gdal read raster, get information, calculate slope/aspect
output: ascii array'''


'''-------------import installed packages-------------'''
from dataclasses import dataclass
import sys
from osgeo import gdal,ogr,osr
import numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QTextBrowser, QVBoxLayout, QHBoxLayout, QMessageBox
from PyQt5.QtGui import QIcon
from matplotlib import pyplot as plt


'''-------------import custom modules------------'''
from WEGIS.develop.UI import Ui_SlopeAsp
from WEGIS.develop.Function import slopeCal
from WEGIS.develop.Function import AspCal
from WEGIS.develop.Function import processings


'''-------window class-----------'''
class Windowslpasp_yzy(Ui_SlopeAsp.Ui_MainWindow, QtWidgets.QDialog): #Windowslpasp_yzy: yzy class-- input raser, calculate slope/aspect
    def __init__(self):
        super(Windowslpasp_yzy, self).__init__()
        self.setupUi(self)

        #*********************global variables********************************
        inputfile=""
        outputfile=""
        oprtype=""


        ###=======click browsein button to select input file=======================
        #-----------------------------------------------------------------------
        self.browsein.clicked.connect(self.msgin) #def msgin(self):

        #=-----------------------------------------------------------------------

        ###=======click browseout button to select output file=======================
        #-----------------------------------------------------------------------
        self.browseout.clicked.connect(self.msgout) #def msgout(self):

        #=-----------------------------------------------------------------------

        ###=======use combo box to select operation=======================
        #-----------------------------------------------------------------------
        self.comboBox.currentIndexChanged.connect(self.setopr) #def setopr(self):

        #=-----------------------------------------------------------------------


        ###=======click cancel to close form=======================
        #-----------------------------------------------------------------------
        self.cancel.clicked.connect(QCoreApplication.instance().quit)

        #=-----------------------------------------------------------------------

        ###=======click ok to complete calculation=======================
        #-----------------------------------------------------------------------
        self.ok.clicked.connect(self.calculateSlpAsp) #def calculateSlpAsp:        
        
        #=-----------------------------------------------------------------------




    '''functions'''


    '''click browsein:
    ----------show file path--------------------------------------'''

    def msgin(self):
        #===============open shapefile====================
        filePath, filetype = QtWidgets.QFileDialog.getOpenFileName(self, "Select File", "./","*.*")
        
        #==================print filename===============
        self.filenamein.setText(filePath)

        #=======================gdal readfile==========================
        try:
            rasterin=gdal.Open(filePath)
            global inputfile
            inputfile=filePath
       
        except:
            msg_box = QMessageBox(QMessageBox.Warning, 'Warning', 'Cannot open file!')
            msg_box.exec_()


    '''click browseout:
    ----------show file path--------------------------------------
    ----------set selected file as output file------------------------------------
    ----------output to file------------------------------'''

    def msgout(self):
        #===============open shapefile====================
        filePath, filetype = QtWidgets.QFileDialog.getOpenFileName(self, "Select File", "./","*.*")
        
        #==================print filename===============
        self.filenameout.setText(filePath)

        #===================set output filename as global============================
        global outputfile
        outputfile=filePath



    '''click combo box:
    ------------------select operation type----------------------------------'''
    def setopr(self):
        global oprtype
        oprtype=self.comboBox.currentText()


    '''click ok:
    --------------------calculate slope/aspect------------------------------'''
    def calculateSlpAsp(self):

        oprtype=self.comboBox.currentText()
        
        #==============read raster file=================
        dataset=gdal.Open(inputfile)
        proj=dataset.GetProjection()
        geotrans=dataset.GetGeoTransform()
        width=geotrans[1]
        height=geotrans[5]
        row=dataset.RasterYSize
        column=dataset.RasterXSize
        band=dataset.RasterCount

        demgrid=dataset.ReadAsArray(0,0,column,row)

        typedata=demgrid.dtype

        if (oprtype=='Calculate Slope'):
            slope=slopeCal.Cacdxdy(demgrid,width,height)
            processings.write_img(outputfile, proj, geotrans, slope, typedata)
            msg_box = QMessageBox(QMessageBox.Information, 'Calculation done', 'Calculation Successful!')
            msg_box.exec_()
        
        elif (oprtype=='Calculate Aspect'):
            aspect=AspCal.CalAsp(demgrid,width,height)
            processings.write_img(outputfile, proj, geotrans, aspect, typedata)
            msg_box = QMessageBox(QMessageBox.Information, 'Calculation done', 'Calculation Successful!')
            msg_box.exec_()
        
        else:
            msg_box = QMessageBox(QMessageBox.Warning, 'Warning', 'Error!')
            msg_box.exec_()


        



'''-----------------------------------------------------------------------------------------------
============main==================main==========================main===========================
-----------------------------------------------------------------------------------------------'''
if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    mywindow = Windowslpasp_yzy()
    mywindow.show()
    sys.exit(app.exec_())