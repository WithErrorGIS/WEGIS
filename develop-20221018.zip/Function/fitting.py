'''
    fitting curves
    functions
'''
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import vario

hlist=vario.dst
gammalist=vario.gam

def linear(h,a,b,r):
    return ((a*h)/r+b)

def sphere(h,a,b,r):
    result=[]
    for i in range(0,len(h)):
        tmp=0.5*math.pow((h[i]/r),3)
        t2=a*(1.5*h[i]/r-tmp)+b
        result.append(t2)
    return(np.asarray(result))


def expo(h,a,b,r):
    result=[]
    for i in range(0,len(h)):
        tmp1=-3*h[i]/r
        tmp=math.exp(tmp1)
        t2=a*(1-tmp)+b
        result.append(t2)
    return(np.asarray(result))
   

def gaus(h,a,b,r):
    result=[]
    for i in range(0,len(h)):
        tmp1=(-(3*h[i]**2.0))/(r**2.0)
        tmp=math.exp(tmp1)
        t2=a*(1-tmp)+b
        result.append(t2)
    return(np.asarray(result))

def plotting(s):
    plot1=plt.plot(vario.dst, vario.gam, '*',label="original")
    plt.plot(vario.dst, after, 'r',label='curve fit values')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend(loc=4)
    plt.title(s)
    plt.show()

popt, pcov = curve_fit(sphere, hlist,gammalist)
after=sphere(vario.dst,popt[0],popt[1],popt[2])

print(popt)

plotting("fitting")