'''18/09/2022, zy yin, H:/2022/Homework/WEGISsystem/week1
python 3.9.12, pyqt 5.15.4
window form for input data: input shapefile data
form: InputRasterUI.ui/InputRasterUI.py
main function: InputRaster.py'''

'''input: raster
processing: gdal read raster, get information
output: ascii array'''


'''-------------import installed packages-------------'''
from dataclasses import dataclass
import sys
from osgeo import gdal
import numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QTextBrowser, QVBoxLayout, QHBoxLayout, QMessageBox
from PyQt5.QtGui import QIcon
from matplotlib import pyplot as plt


'''-------------import custom modules------------'''
from WEGIS.develop.UI  import InputRasterUI as Ui_rasterForm

'''-------window class-----------'''
class Windowinraster_yzy(Ui_rasterForm.Ui_InputRaster_Win, QtWidgets.QDialog): #windowinshape_yzy: yzy class--input shapefile data
    def __init__(self):
        super(Windowinraster_yzy, self).__init__()
        self.setupUi(self)

        #*********************global variables********************************
        rasterdata=[]


        ###=======click browse button to select input file=======================
        #-----------------------------------------------------------------------
        self.browse.clicked.connect(self.msg) #def msg(self):

        #=-----------------------------------------------------------------------


        ###=======click cancel to close form=======================
        #-----------------------------------------------------------------------
        self.cancel.clicked.connect(QCoreApplication.instance().quit)

        #=-----------------------------------------------------------------------

        ###=======click ok to convert raster to array=======================
        #-----------------------------------------------------------------------
        self.ok.clicked.connect(self.okfunction) #def okfunction:        
        
        #=-----------------------------------------------------------------------


    


    '''functions'''


    '''click browse:
    ----------show file path--------------------------------------
    ----------read file content------------------------------------
    ----------convert to geodataframe------------------------------
    ----------preview type and attributes------------------------------'''

    def msg(self):
        #===============open shapefile====================
        filePath, filetype = QtWidgets.QFileDialog.getOpenFileName(self, "Select File", "./","*.*")
        
        #==================print filename===============
        self.filename.setText(filePath)

        #=======================gdal readfile==========================
        try:
            rasterin=gdal.Open(filePath)
        

            #==================print raster information===============================

            #width
            self.widthinfo.setText(str(rasterin.RasterXSize))

            #height
            self.heightinfo.setText(str(rasterin.RasterYSize))

            #bands
            self.bandsinfo.setText(str(rasterin.RasterCount))

            #projection
            self.prjinfo.setText(str(rasterin.GetProjection()))
        
        except:
            msg_box = QMessageBox(QMessageBox.Warning, 'Warning', 'Cannot open file!')
            msg_box.exec_()


        #======================read raster as array============================
        global rasterdata
        rasterdata=self.toasc(rasterin)




    '''----------------------convert raster to ascii array-------------------------------'''
    def toasc(self,rasterin):
        rasterarr=rasterin.ReadAsArray()
        return rasterarr



    '''click ok'''
    def okfunction(self):
        msg_box = QMessageBox(QMessageBox.Information, 'Input done', 'Successfully imported geometry!')
        msg_box.exec_()






'''-----------------------------------------------------------------------------------------------
============main==================main==========================main===========================
-----------------------------------------------------------------------------------------------'''
if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    mywindow = Windowinraster_yzy()
    mywindow.show()
    sys.exit(app.exec_())