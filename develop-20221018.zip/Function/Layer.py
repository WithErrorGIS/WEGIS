import pandas as pd
from WEGIS.develop.Function.Geometry import *
from osgeo import ogr
from osgeo import osr
import os
import sys
import psycopg2

'''-------------import installed packages-------------'''
import pandas as pd
import geopandas as gpd
from PyQt5 import QtGui, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtWidgets import QMessageBox

from sqlalchemy import create_engine

from shapely import geometry as geo2


class Layer(object):

    def __init__(self, _type, name='new_layer', srid=3857, isFromDB=False):
        '''
        :param _type: 图层中几何体的类别，用type类型
        :param name: 图层名字
        '''

        self.type = _type  # 图层中几何体类别，暂时为1点，2线，3面
        self.name = name  # 图层名字
        self.geometries = []  # 几何体列表
        self.isFromDB = isFromDB

        self.dbhost = None
        self.dbport = None
        self.dbbd = None
        self.dbusername = None
        self.dbPWD = None
        self.connection = None
        # 以下为未做部分
        self.visible = True  # 图层可见状态
        self.selectedItems = []  # 被选中的几何体ID（为了使选中几何体和属性表结合）
        self.srid = srid
        self.attr_desp_dict = {'id': 'int'}  # 属性表描述，k为属性名称，v为属性类型，k,v均为str类型
        self.table = pd.DataFrame(columns=['id'])  # 属性表

    def RefreshBox(self):
        '''更新图层的外包矩形'''
        if len(self.geometries) > 0:
            first_box = self.geometries[0].box
            self.box.MinX = first_box.MinX
            self.box.MinY = first_box.MinY
            self.box.MaxX = first_box.MaxX
            self.box.MaxY = first_box.MaxY
            # 遍历所有几何体找到最终的min, max值
            for geometry in self.geometries:
                if geometry.box.MinX < self.box.MinX:
                    self.box.MinX = geometry.box.MinX
                if geometry.box.MinY < self.box.MinY:
                    self.box.MinY = geometry.box.MinY
                if geometry.box.MaxX > self.box.MaxX:
                    self.box.MaxX = geometry.box.MaxX
                if geometry.box.MaxY > self.box.MaxY:
                    self.box.MaxY = geometry.box.MaxY

    def AddGeometry(self, geometry, row=None):
        '''
        向图层中增加几何体
        :param geometry: `Geometry`的子类几何体
        :param row: 可选，该行的属性数据
        '''
        if not isinstance(geometry, self.type):
            raise TypeError('添加几何体类型与图层类型不匹配')
        new_id = 0 if self.table.shape[0] == 0 \
            else self.table['id'].max() + 1
        self.geometries.append(geometry)
        geometry.ID = new_id
        new_row = pd.DataFrame(columns=self.table.columns)
        # 添加属性
        default_val = {'int': 0, 'float': 0.0, 'str': ''}
        if row is None:
            row = {key: default_val[val] for key, val in self.attr_desp_dict.items()}
        for col_name, col_type in self.attr_desp_dict.items():
            if col_name == 'id':
                new_row[col_name] = [new_id]
            elif col_name in row:
                new_row[col_name] = row[col_name] if isinstance(row, pd.DataFrame) else row[col_name] \
                    if isinstance(row[col_name], (tuple, list)) else [row[col_name]]
            else:
                new_row[col_name] = default_val[col_type] if isinstance(default_val[col_type], (tuple, list)) \
                    else [default_val[col_type]]
        self.table = self.table.append(new_row, ignore_index=True)
        self.table.reset_index(drop=True, inplace=True)
        # self.RefreshBox()

    def DelGeometry(self, _id):
        index = None
        for i, geo in enumerate(self.geometries):
            if geo.ID == _id:
                index = i
                break
        if index is not None:
            self.geometries.pop(index)
            self.table.drop(index=self.table[self.table['id'] == _id].index, inplace=True)
            self.table.reset_index(drop=True, inplace=True)
        # self.RefreshBox()

    def add_attr(self, attr_name, attr_type):
        pass

    def del_attr(self, attr_name):
        pass

    def import_from_shplayer(self, geodata):  # 在主函数创建后调用即可，具体看main
        if self.type == Point:
            for index, row in geodata.iterrows():
                ft = self.type(row['geometry'].x, row['geometry'].y, index)
                print(ft)
                self.AddGeometry(ft, None)
        if self.type == Line:
            for index, row in geodata.iterrows():
                data = list()
                temp_line = row['geometry'].xy
                point_count = len(temp_line[0])
                for i in range(point_count):
                    data.append(Point(temp_line[0][i], temp_line[1][i]))
                ft = Line(data, index)
                # print(ft)
                # print(111)
                self.AddGeometry(ft, None)
        if self.type == Polygon:
            for index, row in geodata.iterrows():
                outring = list()
                inring = list()
                temp_polygon = row['geometry']
                temp_polygon_inter = temp_polygon.interiors
                temp_polygon_exter = temp_polygon.exterior
                temp_line = temp_polygon_exter.xy
                for i in range(len(temp_line[0]) - 1):
                    outring.append(Point(temp_line[0][i], temp_line[1][i]))
                    print(Point(temp_line[0][i], temp_line[1][i]))

                if len(temp_polygon_inter) > 0:
                    for j in range(len(temp_polygon_inter)):
                        temp_line_in = temp_polygon_inter[j].xy
                        temp_inring = list()
                        for i in range(len(temp_line_in[0]) - 1):
                            temp_inring.append(Point(temp_line_in[0][i], temp_line_in[1][i]))
                            print(Point(temp_line_in[0][i], temp_line_in[1][i]))
                        inring.append(Polygon(temp_inring))
                ft = Polygon(outring, inring, index)
                print(ft)
                self.AddGeometry(ft, None)

    def import_from_csv(self, geodata):
        if self.type == Point:
        # if isinstance(Point, self.type):
            for index, row in geodata.iterrows():
                ft = self.type(row['geometry'].x, row['geometry'].y, index)
                print(ft)
                self.AddGeometry(ft, None)
        if self.type == Line:
            for index, row in geodata.iterrows():
                data = list()
                temp_line = row['geometry'].xy
                point_count = len(temp_line[0])
                for i in range(point_count):
                    data.append(Point(temp_line[0][i], temp_line[1][i]))
                ft = Line(data, index)
                print(ft)
                self.AddGeometry(ft, None)
        if self.type == Polygon:
            for index, row in geodata.iterrows():
                outring = list()
                inring = list()
                temp_polygon = row['geometry']
                temp_polygon_inter = temp_polygon.interiors
                temp_polygon_exter = temp_polygon.exterior
                temp_line = temp_polygon_exter.xy
                for i in range(len(temp_line[0]) - 1):
                    outring.append(Point(temp_line[0][i], temp_line[1][i]))
                    print(Point(temp_line[0][i], temp_line[1][i]))

                if len(temp_polygon_inter) > 0:
                    for j in range(len(temp_polygon_inter)):
                        temp_line_in = temp_polygon_inter[j].xy
                        temp_inring = list()
                        for i in range(len(temp_line_in[0]) - 1):
                            temp_inring.append(Point(temp_line_in[0][i], temp_line_in[1][i]))
                            print(Point(temp_line_in[0][i], temp_line_in[1][i]))
                        inring.append(Polygon(temp_inring))
                ft = Polygon(outring, inring, index)
                print(ft)
                self.AddGeometry(ft, None)
        print(self.geometries)

    def export_to_shplayer(self, path):
        type_dict = {'int': ogr.OFTInteger,
                     'str': ogr.OFTString,
                     'float': ogr.OFTReal
                     }
        geotype_dict = {
            Point: ogr.wkbPoint,
            Line: ogr.wkbLineString,
            Polygon: ogr.wkbPolygon,

        }
        file_name = path.split('/')[-1]
        related_path = path.split(file_name)[0]
        os.chdir(related_path)
        oDriver = ogr.GetDriverByName('ESRI Shapefile')
        oDs = oDriver.CreateDataSource(file_name)
        if os.path.exists(path):
            oDriver.DeleteDataSource(file_name)
        fields = self.table.columns.tolist()
        dst_osr = osr.SpatialReference()
        dst_osr.ImportFromEPSG(3857)
        outlayer = oDs.CreateLayer(file_name.split('.')[0], dst_osr, geom_type=geotype_dict[self.type])
        for f in fields:
            new_field = ogr.FieldDefn(f, type_dict[self.attr_desp_dict[f]])
            outlayer.CreateField(new_field)
        featureDefn = outlayer.GetLayerDefn()
        for i, g in enumerate(self.geometries):
            geom = ogr.CreateGeometryFromWkt(g.ToWkt())
            ft = ogr.Feature(featureDefn)
            ft.SetGeometry(geom)
            values = self.table.iloc[i].tolist()
            for f, v in zip(fields, values):
                ft.SetField(f, v)
            outlayer.CreateFeature(ft)

    def import_from_db(self, geodata, db_name, db_host, db_port, db_username, db_pwd, conn):

        if self.type == Point:
            for index, row in geodata.iterrows():
                ft = self.type(row['geom'].x, row['geom'].y, index)
                print(ft)
                self.AddGeometry(ft, None)
        if self.type == Line:
            for index, row in geodata.iterrows():
                data = list()
                temp_line = row['geom'].xy
                point_count = len(temp_line[0])
                for i in range(point_count):
                    data.append(Point(temp_line[0][i], temp_line[1][i]))
                ft = Line(data, index)
                print(ft)
                self.AddGeometry(ft, None)
        if self.type == Polygon:
            for index, row in geodata.iterrows():
                outring = list()
                inring = list()
                temp_polygon = row['geom']
                temp_polygon_inter = temp_polygon.interiors
                temp_polygon_exter = temp_polygon.exterior
                temp_line = temp_polygon_exter.xy
                for i in range(len(temp_line[0]) - 1):
                    outring.append(Point(temp_line[0][i], temp_line[1][i]))
                    print(Point(temp_line[0][i], temp_line[1][i]))

                if len(temp_polygon_inter) > 0:
                    for j in range(len(temp_polygon_inter)):
                        temp_line_in = temp_polygon_inter[j].xy
                        temp_inring = list()
                        for i in range(len(temp_line_in[0]) - 1):
                            temp_inring.append(Point(temp_line_in[0][i], temp_line_in[1][i]))
                            print(Point(temp_line_in[0][i], temp_line_in[1][i]))
                        inring.append(Polygon(temp_inring))
                ft = Polygon(outring, inring, index)
                print(ft)
                self.AddGeometry(ft, None)
        self.name = db_name
        self.dbhost = db_host
        self.dbport = db_port
        self.dbbd = db_name
        self.dbusername = db_username
        self.dbPWD = db_pwd
        self.connection = conn
        self.isFromDB = True

    def import_from_raster(self, geodata):

        pass

    def save_to_db(self, savename):
        conn = psycopg2.connect(database='wegis', port=5432, host='localhost', user='postgres',
                                password='RSLrsl123')
        cur = conn.cursor()
        cur.execute("SELECT MAX(fid) FROM layer")
        fetched_rows = cur.fetchall()
        primary_key = fetched_rows[0][0] + 1

        dict_typ = {
            Point: 'POINT',
            Line: 'LINE',
            Polygon: 'POLYGON'

        }

        if self.type == Point:

            # gemo=list()
            # id=list()
            data = list()
            for i in range(len(self.geometries)):
                # id.append(self.geometries[i].ID)
                data.append([self.geometries[i].ID, self.geometries[i].X, self.geometries[i].Y])
            datadf = pd.DataFrame(data)
            datagdf = gpd.GeoDataFrame(datadf[0], geometry=gpd.points_from_xy(datadf[1], datadf[2]))
        if self.type == Line:

            # gemo=list()
            # id=list()
            data = list()
            for i in range(len(self.geometries)):
                # id.append(self.geometries[i].ID)
                data.append([self.geometries[i].ID, self.geometries[i].X, self.geometries[i].Y])
            datadf = pd.DataFrame(data)
            datagdf = gpd.GeoDataFrame(datadf[0], geometry=gpd.points_from_xy(datadf[1], datadf[2]))
        if self.type == Polygon:

            # gemo=list()
            # id=list()
            data = list()
            for i in range(len(self.geometries)):
                # id.append(self.geometries[i].ID)
                data.append([self.geometries[i].ID, self.geometries[i].X, self.geometries[i].Y])
            datadf = pd.DataFrame(data)
            datagdf = gpd.GeoDataFrame(datadf[0], geometry=gpd.points_from_xy(datadf[1], datadf[2]))

        cur.execute("select * from information_schema.tables where table_name=%s", (savename,))
        # engine = create_engine("postgresql://postgres:"+self.dbPWD+"@localhost:5432/"+self.dbbd)
        engine = create_engine("postgresql://postgres:RSLrsl123@localhost:5432/wegis")
        if bool(cur.rowcount):

            datagdf.to_postgis(savename, engine, if_exists='replace')
            print(111)

        else:
            cur.execute(
                "insert into layer(fid,layer_name,shape_type) values({0},'{1}','{2}')".format(primary_key, savename,
                                                                                              dict_typ[self.type]))
            conn.commit()
            datagdf.to_postgis(savename, engine, if_exists='replace')
            print(222)

        # print(geometry)


if __name__ == '__main__':
    """
    读取shp file和csv
    """
    # test = Layer(Polygon)
    # test_data = gpd.GeoDataFrame([geo2.Polygon([(0, 0), (10, 0), (10, 9), (0, 10), (0, 0)],
    #                                            [((1, 3), (5, 3), (5, 1), (1, 1),(1,3)),
    #                                             ((9, 9), (9, 8), (8, 8), (8, 9),(9,9))]
    #                                            )])
    # test.import_from_csv(test_data)
    """
        保存至数据库
        """
    test = Layer(Point)
    test_data = gpd.GeoDataFrame([geo2.Point(117.5, 31.8),
                                  geo2.Point(116.9, 32.5), geo2.Point(116.9, 32.5), geo2.Point(116.9, 32.5),
                                  geo2.Point(116.9, 32.5)])
    test_data = test_data.rename(columns={0: 'geometry'})
    test.import_from_csv(test_data)
